//
//  AppDelegate.m
//  Demo
//
//  Created by xiaoxiao on 2018/7/10.
//  Copyright © 2018年 xiaoxiao. All rights reserved.
//

#import "AppDelegate.h"
#import <JySDK/JySDKManager.h>
// sdk产品code
#define SDK_PRODUCT_CODE @"36844043776657461952074565999473"
// quickAd产品code
#define QUICKAD_PRODUCT_CODE @"87598529833004115693985675723852"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //初始化sdk
    [JySDKManager requestTrackingAuthorization];
    [JySDKManager initWithProductCode:SDK_PRODUCT_CODE completion:^(Status_CODE retCode) {
        if (retCode == kInitSuccess) {
            NSLog(@"初始化成功");
        } else {
            NSLog(@"初始化失败，错误码：%d",retCode);
        }
    }];
    [JySDKManager initQkAd:@"你的quickad参数"];
    [JySDKManager setNeedAutoLogin:NO];
    return YES;
}
    // 微信QQ授权登录回调接口
- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler
{
    return [JySDKManager application:application continueUserActivity:userActivity restorationHandler:restorationHandler];
}
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    return [JySDKManager application:app openURL:url options:options];
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [JySDKManager application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
