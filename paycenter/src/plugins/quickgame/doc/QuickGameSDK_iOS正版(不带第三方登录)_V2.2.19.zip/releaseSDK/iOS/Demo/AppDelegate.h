//
//  AppDelegate.h
//  Demo
//
//  Created by xiaoxiao on 2018/7/10.
//  Copyright © 2018年 xiaoxiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

