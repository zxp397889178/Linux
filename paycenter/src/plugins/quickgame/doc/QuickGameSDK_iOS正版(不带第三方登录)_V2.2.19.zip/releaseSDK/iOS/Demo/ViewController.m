//
//  ViewController.m
//  Demo
//
//  Created by xiaoxiao on 2018/7/10.
//  Copyright © 2018年 xiaoxiao. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+GIF.h"
#import <JySDK/JySDKManager.h>

@interface ViewController ()<KAcountDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (nonatomic, strong) UIImage *imageH;

@end

@implementation ViewController

//iphoneX系列设备自动隐藏home键
- (BOOL)prefersHomeIndicatorAutoHidden
{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self demoConfig];
    
    //设置代理，监听用户退出事件
    [JySDKManager defaultManager].acountDelegate = self;
/**
 实名认证回调
 iscomplete 是否完成实名认证
age 实名认证后返回实际年龄否则返回0
source 1登录调起实名认证2用户主动调起3支付调起4用户中心进入
 */
    [JySDKManager completeRealName:^(BOOL isComplete, NSInteger age, NSInteger source) {
        NSLog(@"%@年龄%ld",isComplete ? @"完成实名认证":@"未完成实名认证", (long)age);
    }];
}

#pragma mark - 登录
- (IBAction)login:(UIButton *)sender {
    /** 两个方法二选一根据是否需要登录失败回调选用 */
//    [JySDKManager loginWithSuccBlock:^(NSDictionary *resultDic) {
//
//    } failBlock:^(NSString *message) {
//
//    }];
    [JySDKManager login:^(NSDictionary *resultDic) {
        NSString *code = [resultDic objectForKey:@"code"];
        NSString *token = [JySDKManager userToken];
        switch (code.integerValue) {
            case kErrorNone:{
                
                NSString *userid = [resultDic objectForKey:@"userId"];
                NSLog(@"登录成功:\n用户ID:%@,验证码:%@",userid,token);
                
                if([JySDKManager isGuest]){
                    NSLog(@"是游客登录");
                }else{
                    NSLog(@"非游客登录");
                }
                // 登录成功， 上传角色信息
                GameRole *role = [GameRole new];
                role.roleId = @"testRoleid";  /// 必传
                role.role_name = @"testRoleName";
                role.serverId = @"1";
                role.sv_name = @"testServer";
                role.role_level = @"testRoleLevel";
                role.vipLevel = @"testVipLevel";
                [JySDKManager updateRoleInfo:role];
                NSString * age = JySDKManager.getCurrentUserAge;
                NSLog(@"当前用户UID=%@，年龄=%@", JySDKManager.userId, age);
            }
                break;
                
            default:
                break;
        }
    }];
    
}

#pragma mark - 退出登录
- (IBAction)logout:(UIButton *)sender {
    
    [JySDKManager logout:^{
        
    }];
    
}
- (IBAction)actionOnRealName:(UIButton *)sender {
    [JySDKManager enterRealName];
}
#pragma mark - 支付
- (IBAction)pay:(UIButton *)sender {
    if (![JySDKManager isLogined]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"请先登录" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    GoodParam *param = [GoodParam new];
    
    param.productId = @"nsgs_20190812_130twd"; ///商品id ,必填 // com.game.xianxiawu
    param.productName = @"宝石";
    //param.productDesc = @"sixBaoshi";
    param.price = 1;    ///商品单价 必填
    param.orderNo = @"orderNo_xxx";     ///游戏方订单号 string[64] 必填、必须唯一  /// 注意： 接入QuickAd时、游戏订单号 必传 且 必须唯一 ///
    param.url = nil;    ///回调通知地址 string[200] 可选  客户端配置优先;  可传nil
    param.extras = @"role_buy_1_baoshi1"; ///透传参数  可选
    
    [JySDKManager getGoodWithParam:param completion:^(NSDictionary *resultDic) {
        NSLog(@"%@",resultDic);
        NSString *code = [resultDic objectForKey:@"code"];
        NSString *msg = [resultDic objectForKey:@"message"];
        NSString *productId; //商品id
        NSData *receipt;   //购买后的凭据
        NSString *tranactionId; //交易号
        switch (code.integerValue) {
            case KOrderSuccess:
            {
                NSLog(@"购买成功，订单号:%@",msg);
                //获取内购相关信息
                productId = [resultDic objectForKey:@"productIdentifier"]; //内购商品id
                receipt = [resultDic objectForKey:@"receipt"]; //内购交易凭据
                tranactionId = [resultDic objectForKey:@"transactionId"]; //内购交易id
                

            }
                break;
            case KOrderFail:
                break;
            case KOrderCancel:
                NSLog(@"失败原因：%@",msg);
                break;
            case KOrderUnkown:
                break;
            default:
                break;
        }
    }];
}

#pragma mark - 用户中心
- (IBAction)userCenter:(UIButton *)sender {
    if (![JySDKManager isLogined]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"请先登录" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    [JySDKManager showUserCenter];
}

#pragma mark - 显示浮标
- (IBAction)showFloat:(UIButton *)sender {
    if (![JySDKManager isLogined]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"请先登录" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        return;
    }
    

}

#pragma mark - 隐藏浮标
- (IBAction)hideFloat:(UIButton *)sender {

}

#pragma mark -- KAcountDelegate
- (void)userLogout:(NSDictionary *)resultDic
{
    NSLog(@"用户从个人中心手动登出。\n%@",resultDic);
    [self login:nil];
}
- (void)userRegister:(NSString *)uid
{
    NSLog(@"注册账号：%@",uid);
}
- (void)outService:(NSDictionary *)resultDic
{
    NSLog(@"点击了客服按钮");
}
#pragma mark - demoConfig
- (void)demoConfig
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"bg_heng" ofType:@"gif"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    self.imageH = [UIImage sd_animatedGIFWithData:data];
    self.imgView.image = self.imageH;
}

#pragma mark -- Autorotate
- (BOOL)shouldAutorotate
{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}


@end
