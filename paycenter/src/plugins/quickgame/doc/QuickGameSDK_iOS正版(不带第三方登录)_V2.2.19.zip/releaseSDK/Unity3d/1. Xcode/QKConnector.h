
//

#import <Foundation/Foundation.h>
#import <JySDK/JySDKManager.h>

@interface QKConnector : NSObject<KAcountDelegate>

+(QKConnector *)shareInstance;

@end
