 package com.example.sysdk_demo;

import org.json.JSONObject;

import com.example.sydemo.R;
import com.shunyou.sdk.SYSDKManager;
import com.shunyou.sdk.bean.RoleInfo;
import com.shunyou.sdk.listener.LoginResult;
import com.shunyou.sdk.listener.OnExitListener;
import com.shunyou.sdk.listener.OnUserLogoutListener;
import com.shunyou.sdk.listener.PaymentResult;
import com.sygame.sdk.domain.OnVerifyListener;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SDKActivity extends Activity implements OnClickListener {

	private boolean hasLogin = false;	// 登录成功后才可调用上传角色信息接口
	private SYSDKManager sdkmanager;
	private EditText et_money;
	private TextView tv_msg;
	private Button btn_login, btn_charger, btn_logout, btn_upInfo, btn_verify, btn_exit;
	private String userName;
	private static String TAG = "LOGOUT-i";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.sysdk_demo_activity);
		/**
		 * 逗游SDK初始化
		 */
		sdkmanager = SYSDKManager.getInstance(this);
		sdkmanager.init(this);
		sdkmanager.onCreate();
		/*** END OF INITIALIZE */

		/** 设置帐号注销的监听 */
		sdkmanager.setUserLogoutListener(new OnUserLogoutListener() {

			@Override
			public void onLogoutSuccess(int code, String msg) {
				// 注销成功
				hasLogin = false;
				Toast.makeText(getApplication(), "提示：" + msg, Toast.LENGTH_LONG).show();
			}

			@Override
			public void onLogoutFailure(int code, String msg) {
				// 注销失败
				Toast.makeText(getApplication(), "提示：" + msg, Toast.LENGTH_LONG).show();
			}
		});
		btn_login = (Button) findViewById(R.id.btn_login);
		btn_logout = (Button) findViewById(R.id.btn_logout);
		btn_charger = (Button) findViewById(R.id.btn_charger);
		btn_upInfo = (Button) findViewById(R.id.btn_updateInfo);	
		btn_exit = (Button) findViewById(R.id.btn_exit);
		btn_verify = (Button) findViewById(R.id.btn_realNameVerify);
		et_money = (EditText) findViewById(R.id.et_money);

		btn_login.setOnClickListener(this);
		btn_charger.setOnClickListener(this);
		btn_upInfo.setOnClickListener(this);
		btn_logout.setOnClickListener(this);
		btn_verify.setOnClickListener(this);
		btn_exit.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (null != btn_login && btn_login.getId() == v.getId()) {
/*			sdkmanager.thirdLogin(SDKActivity.this, "weixin", "abc123456", new OnLoginListener() {
				
				@Override
				public void onLoginSuccess(LoginResult result) {
					Toast.makeText(getApplication(), "登录成功：" + result.username, Toast.LENGTH_LONG).show();
				}
				
				@Override
				public void onLoginFailure(int code, String msg) {
					Toast.makeText(SDKActivity.this, "登录失败:" + code + "," + msg, Toast.LENGTH_LONG).show();
				}
			});*/
			sdkmanager.login(SDKActivity.this, false, new com.shunyou.sdk.listener.OnLoginListener() {

				@Override
				public void onLoginSuccess(LoginResult result) {
					String sign = result.sign;// 登录成功返回的签名,需要做验证处理
					long loginTime = result.logintime;// 登录回调时间戳
					userName = result.username;// KD 登录的用户名
					String memkey = result.memkey;// 平台登录返回的Token KEY，用于登录验证
					hasLogin = true;
					Log.i("SHUNYOU", "sign:" + sign);
					Toast.makeText(getApplication(), "登录成功：" + result.username, Toast.LENGTH_LONG).show();
				}

				@Override
				public void onLoginFailure(int code, String msg) {
					Toast.makeText(SDKActivity.this, "登录失败:" + code + "," + msg, Toast.LENGTH_LONG).show();
					Log.d(TAG, "onLoginFailure");
				}
			});
			return;
		}

		if (null != btn_logout && btn_logout.getId() == v.getId()) {
			sdkmanager.logout();
			return;
		}
		
		if (null != btn_verify && btn_verify.getId() == v.getId()) {
			sdkmanager.queryRealNameVerify(userName, new OnVerifyListener() {
				
				@Override
				public void onQuerySuccess(int code, String msg, JSONObject data) { // code为0：未实名，1：已实名
					if (code == 1) {
						Toast.makeText(getApplication(), msg + "," + data.toString(), Toast.LENGTH_LONG).show();
					} else {
						Toast.makeText(getApplication(), msg, Toast.LENGTH_LONG).show();
					}
				}
			});
			return;
		}

		if (null != btn_exit && btn_exit.getId() == v.getId()) {
			sdkmanager.exit(SDKActivity.this, new OnExitListener() {

				@Override
				public void onSuccess() {
					// 退出成功
					Toast.makeText(getApplication(), "退出成功", Toast.LENGTH_LONG).show();
					finish();
				}

				@Override
				public void onFailure() {
					// TODO Auto-generated method stub

				}
			});
			return;
		}

		if (null != btn_charger && btn_charger.getId() == v.getId()) {
			String money_str = et_money.getText().toString().trim();
			String money = "1";
			if (!TextUtils.isEmpty(money_str) && !"".equals(money_str)) {
				money = money_str;
			}
			sdkmanager.pay(this, "roleid", "rulename", "rolelevel", money, "1", "1", "60元宝", "元宝", "123456789",
					new com.shunyou.sdk.listener.OnPaymentListener() {

						@Override
						public void onPaySuccess(PaymentResult result) {
							Log.d(TAG, "onPaySuccess");
							Toast.makeText(getApplication(), "充值金额数:" + result.money + " 消息提示:" + result.msg,
									Toast.LENGTH_LONG).show();
						}

						@Override
						public void onPayFailure(int code, String msg, String money) {
							Log.d(TAG, "onPayFailure");
							Toast.makeText(getApplication(), "错误码:" + code + "  ErrorMsg:" + msg + "  金额：" + money,
									Toast.LENGTH_LONG).show();
						}
					});

			return;
		}
		// 提交角色信息
		if (null != btn_upInfo && btn_upInfo.getId() == v.getId()) {
			if (true) {
				RoleInfo role = new RoleInfo();
				role.setCreateRole(false);
				role.setPartyName("SAO");
				role.setRoleBalance("999");
				role.setRoleCreateTime("");
				role.setRoleID("1001");
				role.setRoleLevel("99");
				role.setRoleName("Kirito");
				role.setServerID("1");
				role.setServerName("OL");
				role.setVipLevel("15");
				role.setRebornLevel("2");
				role.setPower("999");
				role.setExtend("pp");
				sdkmanager.updateGameRoleData(this, role);
			}
		}

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		sdkmanager.onConfigurationChanged(newConfig);
		super.onConfigurationChanged(newConfig);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		sdkmanager.onNewIntent(intent);
		super.onNewIntent(intent);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		sdkmanager.onActivityResult(requestCode, resultCode, data);
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	protected void onPause() {
		sdkmanager.onPause();
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		sdkmanager.onDestroy();
		super.onDestroy();
	}

	@Override
	protected void onStop() {
		sdkmanager.onStop();
		super.onStop();
	}

	@Override
	protected void onStart() {
		sdkmanager.onStart();
		super.onStart();
	}

	@Override
	protected void onResume() {
		sdkmanager.onResume();
		super.onResume();
	}

	@Override
	protected void onRestart() {
		sdkmanager.onRestart();
		super.onRestart();
	}

	@Override
	public void onBackPressed() {
		sdkmanager.onBackPressed();
		// 接入退出接口
		sdkmanager.exit(SDKActivity.this, new OnExitListener() {

			@Override
			public void onSuccess() {
				java.lang.System.exit(0);
			}

			@Override
			public void onFailure() {

			}
		});
		return;
	}

}
