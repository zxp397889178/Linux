package com.example.sysdk_demo;

import com.shunyou.sdk.sy.ShunyouSplashActivity;

import android.content.Intent;

public class SplashActivity extends ShunyouSplashActivity {

	@Override
	public void onFinish() {
		Intent intent = new Intent(this, SDKActivity.class);
		startActivity(intent);
		this.finish();
	}

}
