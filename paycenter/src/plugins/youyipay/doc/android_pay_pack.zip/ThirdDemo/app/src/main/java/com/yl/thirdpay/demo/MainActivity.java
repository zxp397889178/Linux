package com.yl.thirdpay.demo;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.clock.intel.GdInitListener;
import com.clock.intel.GdPay;
import com.clock.intel.GdPayListener;
import com.clock.intel.LgResult;
import com.clock.intel.OnLoginListener;
import com.yl.thirdpay.R;


public class MainActivity extends Activity implements OnClickListener {

	String TAG = "PayTest";

	Button init, pay, login, activate;

	EditText appId,sourceId,goodsId,goodsPrice,goodsnub;

	int orderId;

	// 初始化方法 使用
	String appid = "AP12411014203014220001";
	String sourceid = "third_pay";
	String goodsid = "P18042886S0";
	int goodsprice = 1;
	int goodsnum = 1;
	Activity mcontext;
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		System.out.println("MainActivity.onCreate()");
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.activity_main);
		 initLists();
		// /////////////////////////////SDK接入部分初始化////Start////////////////////////////////
		mcontext = this;
		/**
		 * 第0步，防止SD卡安装游戏第一次从系统安装器打开游戏支付出现按home键支付流程中断
		 */
		if (!this.isTaskRoot()) {
			Intent mainIntent = getIntent();
			String action = mainIntent.getAction();
			if (mainIntent.hasCategory(Intent.CATEGORY_LAUNCHER)
					&& action.equals(Intent.ACTION_MAIN)) {
				finish();
				return;
			}
		}
	}


		private GdPayListener payListener = new GdPayListener() {

		@Override
		public void onPayResult(int requestCode, int resultCode, Intent data) {
			if (data == null) {
				return;
			}
			Bundle bundle = data.getExtras();
			if (null != bundle) {
				boolean is_success = resultCode == 100;// 是否成功
				String real_price = "" + bundle.getInt("order_price");// 本次支付费用
				String user_order_id = "" + bundle.getString("order_id");// 用户定义的订单号
				String pay_order_id = "" + bundle.getString("pay_order_id");// 后台生成定义的订单号
				String error_code = "" + bundle.getString("pay_result_id");//
				// 支付结果，主要是指错误Code
				String error_msg = "" + bundle.getString("pay_result_msg");// 失败时返回的错误原因
				Log.d(TAG, "user_order_id :"+ user_order_id + "   pay_order_id" + pay_order_id + " error_msg"+error_msg);
			
				if (is_success) {// 支付成功
					Toast.makeText(mcontext, error_msg,
							Toast.LENGTH_LONG).show();
				} else { // 支付失败
					Toast.makeText(MainActivity.this, "支付失败3:" + error_msg,
							Toast.LENGTH_LONG).show();
				}

			}

		}
	};
	
	
	private OnLoginListener onLoginListener = new OnLoginListener() {

		@Override
		public void onReslut(LgResult lgResult) {
			Toast.makeText(mcontext, "code:" + lgResult.getCode() + "openId" + lgResult.getOpenId() + "tokenId"+ lgResult.getTokenId() + "msg" + lgResult.getMsg() , Toast.LENGTH_LONG).show();
			Log.d(TAG, lgResult.toString());
		}
       
    };


	/**
	 * DEMO点击计费模拟操作
	 */
	@Override
	public void onClick(View v) {

		orderId++;
		String mappid = appId.getText().toString();
		if(!TextUtils.isEmpty(mappid)){
			appid = mappid;
		}else {
			appid = appId.getHint().toString();
		}
		String msourceid = sourceId.getText().toString();
		if(!TextUtils.isEmpty(msourceid)){
			sourceid = msourceid;
		}else{
			sourceid = sourceId.getHint().toString();
		}
		
		String mgoodsid = goodsId.getText().toString();
		if(!TextUtils.isEmpty(mgoodsid)){
			goodsid = mgoodsid;
		}else {
			goodsid = goodsId.getHint().toString();
		}
		
		String mgoodsprice = goodsPrice.getText().toString();
		if(!TextUtils.isEmpty(mgoodsprice)){
			goodsprice = Integer.valueOf(mgoodsprice);
		}else {
			goodsprice = Integer.valueOf(goodsPrice.getHint().toString());
		}
		
		String mgoodsnum = goodsnub.getText().toString();
		if(!TextUtils.isEmpty(mgoodsnum)){
			goodsnum = Integer.valueOf(mgoodsnum);
		}else {
			goodsnum = Integer.valueOf(goodsnub.getHint().toString());
		}
		
		switch (v.getId()) {
		case R.id.startPay: //支付
//			new Thread(new Runnable() {
//				
//				@Override
//				public void run() {
//					// TODO Auto-generated method stub
//					AppTache.requestPay(mcontext, false, goodsprice, goodsnum, goodsid,
//							"60咸鱼", "20171107110510dev416465080", 1, "11111",payListener);	
//				}
//			}).start();
			mcontext.runOnUiThread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					GdPay.requestPay(mcontext, false, goodsprice, goodsnum, goodsid,
							"60咸鱼", "20171107110510dev416465080", 1, "",payListener);	
				}
			});


			break;
		
		case R.id.init:  //初始化
			GdPay.init(this, new GdInitListener() {

				@Override
				public void onInitFinish(int code, String msg) {

					if (code == GdInitListener.CODE_FAILED) {
						Toast.makeText(MainActivity.this, "初始化失败！" + msg,
								Toast.LENGTH_LONG).show();
					} else if (code == GdInitListener.CODE_SUCCESS) {
						Toast.makeText(MainActivity.this, "初始化成功!" + msg,
								Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(MainActivity.this, "未知异常，请联系开发！",
								Toast.LENGTH_SHORT).show();
					}

				}

				@Override
				public boolean onUpdateEnd() {
					// TODO Auto-generated method stub
					return false;
				}

				@Override
				public boolean onUpdateStart() {
					// TODO Auto-generated method stub
					return false;
				}
			}, appid, sourceid);
		
			break;
			
		case R.id.login: //登录
			GdPay.login(MainActivity.this, onLoginListener);	
			break;
		case R.id.activate:
			SharedPreferences sp = MainActivity.this.getSharedPreferences("LANG_SDK_PREF", Activity.MODE_PRIVATE);
			Toast.makeText(MainActivity.this, sp.getString("KEY_APPID",null),
					Toast.LENGTH_SHORT).show();
//			GdPay.activate(mcontext, new Handler(){
//
//				@Override
//				public void handleMessage(Message msg) {
//					switch (msg.what) {
//					case 300:
//						Toast.makeText(MainActivity.this, "激活成功！",
//								Toast.LENGTH_SHORT).show();
//						break;
//
//					default:
//						Toast.makeText(MainActivity.this, "激活失败！",
//								Toast.LENGTH_SHORT).show();
//						break;
//					}
//			
//				}
//				
//			});	
//			break;
		}			

	}



	/**
	 * DEMO自身界面交互
	 */
	private void initLists() {
		init = (Button) findViewById(R.id.init);
		init.setOnClickListener(this);
		pay = (Button) findViewById(R.id.startPay);
		pay.setOnClickListener(this);
		login = (Button) findViewById(R.id.login);
		login.setOnClickListener(this);
		activate = (Button) findViewById(R.id.activate);
		activate.setOnClickListener(this);
		appId = (EditText) findViewById(R.id.appid);
		appId.setHint(appid);
		sourceId = (EditText) findViewById(R.id.sourceid);
		sourceId.setHint(sourceid);
		goodsId = (EditText) findViewById(R.id.goodsid);
		goodsId.setHint(goodsid);
		goodsPrice = (EditText) findViewById(R.id.goodsprice);
		goodsPrice.setHint(goodsprice+"");
		goodsnub = (EditText) findViewById(R.id.goodsnub);
		goodsnub.setHint(goodsnum+"");
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exitApp();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * 退出程序
	 */
	private void exitApp() {
		finish();
	}

}

