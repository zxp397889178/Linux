package com.yl.thirdpay.demo.wxapi;

import com.clock.intel.plugin.WXCallBackActivity;


public class WXEntryActivity extends WXCallBackActivity {

}
