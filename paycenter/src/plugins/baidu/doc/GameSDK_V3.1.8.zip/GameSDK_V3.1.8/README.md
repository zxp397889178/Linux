单机SDK Project

单机SDK客户端和中间层接口文档：http://doc.iduoku.cn/pages/viewpage.action?pageId=10748067
