import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * 读取APK信息
 * 
 * @author zhengjihan01
 *
 */
public class ApkReader {

    public static String readApkXml(File apkDir, PackageInfo info) {
//        System.out.println("apkDir=" + apkDir);
        for (File file : apkDir.listFiles()) {
            if (!file.isDirectory() && file.getName().equals("AndroidManifest.xml")) {
                try {
                    ManifestParser.parse(new FileInputStream(file), info);
                    String schemeResult = ManifestParser.checkScheme(new FileInputStream(file));
                    String authoritiesResult = ManifestParser.checkAuthorities(new FileInputStream(file));
                    return schemeResult + authoritiesResult;
                } catch (FileNotFoundException e) {
                    System.out.println("apk directory not found!");
                }
            }
        }
        return null;
    }

    /*
     * public static InputStream getXmlInputStream(File apk) { InputStream inputStream = null; InputStream
     * xmlInputStream = null; ZipFile zipFile = null; try { zipFile = new ZipFile(apk); ZipEntry zipEntry = new
     * ZipEntry("AndroidManifest.xml"); inputStream = zipFile.getInputStream(zipEntry); AXMLPrinter xmlPrinter = new
     * AXMLPrinter(); xmlPrinter.startPrinf(inputStream); xmlInputStream = new
     * ByteArrayInputStream(xmlPrinter.getBuf().toString().getBytes("UTF-8")); } catch (IOException e) {
     * e.printStackTrace(); try { inputStream.close(); zipFile.close(); } catch (IOException e1) { e1.printStackTrace();
     * } } return xmlInputStream; }
     */

    /**
     * 在apk反编译后的目录下遍历res\lib\assets这3个目录,把所有文件名称和路径写入packageInfo
     * @param apkDir
     * @param info
     */
    public static void readApkFile(File apkDir, PackageInfo info) {
        for (File file : apkDir.listFiles()) {
            if (file.isDirectory() && file.getName().equals("res")) {
                FileParser.handleRes(file, info);
            } else if (file.isDirectory() && file.getName().equals("lib")) {
                FileParser.handleLibs(file, info);
            } else if (file.isDirectory() && file.getName().equals("assets")) {
                FileParser.handleAssets(file, info);
            }
        }
        /*
         * try { InputStream is = new BufferedInputStream( new FileInputStream(apkDir)); ZipInputStream zis = new
         * ZipInputStream(is); ZipEntry ze; while ((ze = zis.getNextEntry()) != null) { if
         * (ze.getName().startsWith("res/")) { info.resList.add(ze.getName().replaceAll("-v4", "")); } else if
         * (ze.getName().startsWith("lib/")) { info.libList.add(ze.getName()); } else if
         * (ze.getName().startsWith("assets/")) { info.assetList.add(ze.getName()); } } zis.closeEntry(); } catch
         * (FileNotFoundException e) { System.out.println("apk file not found!"); } catch (IOException e) {
         * e.printStackTrace(); }
         */
    }

    public static void readApkValue(File apkDir, PackageInfo info) {
        File[] files = apkDir.listFiles();
        if (files == null || files.length == 0) {
            return;
        }
        for (File file : files) {
            if (file.isDirectory() && "res".equals(file.getName())) { // 如果是res文件夹
                File[] values = file.listFiles(new FileFilter() {

                    @Override
                    public boolean accept(File pathname) {
                        if (pathname != null && pathname.isDirectory() && pathname.getName().startsWith("values")) {
                            return true;
                        }
                        return false;
                    }
                });
                System.out.println("parsing apk values...");
                ValueParser.parse(values, info);
            }
        }
    }

    /**
     * 在当前目录下寻找target目录
     * @return
     */
    public static File findApk() {
        File dir = new File(System.getProperty("user.dir"));
        File target = null;
        if (!dir.isDirectory()) {
            return null;
        }
        File[] files = dir.listFiles(new FileFilter() {

            @Override
            public boolean accept(File arg0) {
                if (arg0 != null && arg0.isDirectory() && "target".equals(arg0.getName())) {
                    return true;
                }
                return false;
            }
        });
        if (files != null && files.length > 0) {
            target = files[0];
        }
        return target;
    }

}
