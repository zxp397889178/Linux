import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

public class ValueParser {

    public static void parse(File[] values, PackageInfo info) {
        List<File> xmlList = new ArrayList<File>();
        fetchAllXmlFile(values, xmlList);
        for (File xml : xmlList) {
            parseXml(xml, info.valueList);
        }
    }

    private static void fetchAllXmlFile(File[] files, List<File> xmlList) {
        for (File file : files) {
            if (file.isDirectory()) {
                fetchAllXmlFile(file.listFiles(), xmlList);
            } else if (file.getName().endsWith(".xml")) {
                xmlList.add(file);
            }
        }
    }

    private static void parseXml(File xml, List<String> valueList) {
        SAXBuilder saxBuilder = new SAXBuilder();
        try {
            FileInputStream in = new FileInputStream(xml);
            Document document = saxBuilder.build(in);
            Element root = document.getRootElement();
            if (root == null) {
                return;
            }
            List list = root.getChildren();
            if (list == null || list.size() == 0) {
                return;
            }
            for (Object object : list) {
                if (object instanceof Element) {
                    Element e = (Element) object;
                    String tag = e.getName();
                    String name = e.getAttributeValue("name");
                    if (name == null || name.trim().equals("")) {
                        continue;
                    }
                    if ("declare-styleable".equals(tag)) {
                        continue;
                    }
                    if ("item".equals(tag)) {
                        tag = e.getAttributeValue("type");
                    }
                    valueList.add(tag + ":" + name);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
