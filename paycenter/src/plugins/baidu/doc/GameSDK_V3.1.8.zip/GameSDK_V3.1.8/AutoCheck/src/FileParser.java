import java.io.File;
import java.util.List;

public class FileParser {

    public static void handleAssets(File assetDir, PackageInfo info) {
        for (File file : assetDir.listFiles()) {
            fetchFileTillNotDir(file, "assets", info.assetList);
        }
    }

    public static void handleLibs(File libDir, PackageInfo info) {
        for (File file : libDir.listFiles()) {
            if (!file.getName().endsWith(".jar") && !file.getName().endsWith("armeabi-v7a")) { // 因为class文件都打包到classes.dex里了，所以不比对jar文件
                fetchFileTillNotDir(file, "lib", info.libList);
            }
        }
    }

    public static void handleRes(File resDir, PackageInfo info) {
        for (File file : resDir.listFiles()) {
            if (!file.getName().startsWith("values")) { // values里的资源需要单独处理
                fetchFileTillNotDir(file, "res", info.resList);
            }
        }
    }

    public static void fetchFileTillNotDir(File file, String dir, List<String> list) {
//        System.out.println("file:"+file+",dir="+dir);
        if (file.isDirectory()) {
            for (File sub : file.listFiles()) {
                if ("Thumbs.db".equals(sub.getName()) || sub.getName().endsWith(".DS_Store")) { // 过滤这个文件
                    continue;
                }
                fetchFileTillNotDir(sub, dir + "/" + file.getName(), list);
            }
        } else {
//            System.out.println("加入文件:" + dir + "/" + file.getName());
        	if (dir.contains("drawable")) {
				//只检查文件名，因为有的CP在接入时会把drawable-hdpi这种目录下的资源文件放到不同的版本后缀下，在R文件中同一名称的drawabel资源是唯一名称的
	        	list.add(file.getName());
			} else {
        		list.add(dir + "/" + file.getName());
			}
        }
    }

}
