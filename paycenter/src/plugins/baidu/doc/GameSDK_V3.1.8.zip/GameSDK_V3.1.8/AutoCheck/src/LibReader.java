import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class LibReader {

    public static void readLibXml(File lib, PackageInfo info) {
        for (File file : lib.listFiles()) {
            if (!file.isDirectory() && file.getName().equals("AndroidManifest.xml")) {
                try {
                    ManifestParser.parse(new FileInputStream(file), info);
                } catch (FileNotFoundException e) {
                    System.out.println("lib工程未找到！");
                }
            }
        }
    }

    public static void readLibFile(File lib, PackageInfo info) {
        for (File file : lib.listFiles()) {
            if (file.isDirectory() && file.getName().equals("res")) {
                FileParser.handleRes(file, info);
            } else if (file.isDirectory() && file.getName().equals("libs")) {
                FileParser.handleLibs(file, info);
            } else if (file.isDirectory() && file.getName().equals("assets")) {
                FileParser.handleAssets(file, info);
            }
        }
    }

    public static void readLibValue(File lib, PackageInfo info) {
        File[] files = lib.listFiles();
        if (files == null || files.length == 0) {
            return;
        }
        for (File file : files) {
            if (file.isDirectory() && "res".equals(file.getName())) { // 如果是res文件夹
                File[] values = file.listFiles(new FileFilter() {

                    @Override
                    public boolean accept(File pathname) {
                        if (pathname != null && pathname.isDirectory() && pathname.getName().startsWith("values")) {
                            return true;
                        }
                        return false;
                    }
                });
                System.out.println("parsing lib values...");
                ValueParser.parse(values, info);
            }
        }
    }

    public static File findLib() {
//        File dir = new File(System.getProperty("user.dir")).getParentFile();
    	File dir = new File(System.getProperty("user.dir"));
        if (!dir.isDirectory()) {
            return null;
        }
        return searchLib(dir);
    }

    private static File searchLib(File dir) {
        for (File file : dir.listFiles()) {
            if (!file.isDirectory()) {
                continue; // 非文件夹的直接跳过
            }
            if ("DKSingleSDK_SDKProject".equals(file.getName())) {
                return file;
            } else {
                File objFile = searchLib(file);
                if (objFile != null) {
                    return objFile;
                }
            }
        }
        return null;
    }

}
