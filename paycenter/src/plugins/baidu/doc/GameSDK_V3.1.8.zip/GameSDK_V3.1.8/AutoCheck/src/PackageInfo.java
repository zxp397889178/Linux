import java.util.ArrayList;
import java.util.List;

public class PackageInfo {
    public List<String> resList;
    public List<String> libList;
    public List<String> assetList;
    public List<String> permissionList;
    public List<String> activityList;
    public List<String> serviceList;
    public List<String> receiverList;
    public List<String> providerList;
    public List<String> metaList;
    public String sdkVersion;
    public List<String> valueList;

    /**
     * 包熟悉构造器
     * 熟悉包括:res文件列表,lib文件列表,asset文件列表,permission列表,activity列表,service列表,reveiver列表,provider列表, values资源列表
     */
    public PackageInfo() {
        resList = new ArrayList<String>();
        libList = new ArrayList<String>();
        assetList = new ArrayList<String>();
        permissionList = new ArrayList<String>();
        activityList = new ArrayList<String>();
        serviceList = new ArrayList<String>();
        receiverList = new ArrayList<String>();
        providerList = new ArrayList<String>();
        metaList = new ArrayList<String>();
        valueList = new ArrayList<String>();
    }
}
