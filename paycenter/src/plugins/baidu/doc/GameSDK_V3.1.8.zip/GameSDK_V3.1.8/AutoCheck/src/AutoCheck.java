import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class AutoCheck {


    public static void main(String[] args) {
        List<String> absentConfig = new ArrayList<String>();
        List<String> absentFile = new ArrayList<String>();
        List<String> absentValue = new ArrayList<String>();
        String sdkVersion;
        String otherCheck = null;

        PackageInfo apkInfo = new PackageInfo();
        //寻找target目录,即target.apk被apktool反编译后的目录
        File apk = ApkReader.findApk();
        if (apk == null || !apk.exists()) {
            System.out.println("请确保当前目录下有要自检的source.apk文件。");
            return;
        }

        System.out.println("开始读取apk资源...");
        ApkReader.readApkFile(apk, apkInfo);
        otherCheck = ApkReader.readApkXml(apk, apkInfo);
//        System.out.println("read otherCheck=" + otherCheck);
        ApkReader.readApkValue(apk, apkInfo);
        System.out.println("读取完成");

        PackageInfo libInfo = new PackageInfo();
        File lib = LibReader.findLib();
        if (lib == null || !lib.exists()) {
            System.out.println("lib工程未找到。");
            return;
        }

        System.out.println("开始读取lib工程资源...");
        LibReader.readLibFile(lib, libInfo);
        LibReader.readLibXml(lib, libInfo);
        LibReader.readLibValue(lib, libInfo);
        System.out.println("读取完成");
        System.out.println("开始比对...");

        // 比对配置
        absentConfig.add("缺少的uses-permission:");
        for (String string : libInfo.permissionList) {
            if (apkInfo.permissionList.indexOf(string) < 0) {
                absentConfig.add(string);
            }
        }
        absentConfig.add("缺少的activity配置:");
        for (String string : libInfo.activityList) {
            if (apkInfo.activityList.indexOf(string) < 0) {
                absentConfig.add(string);
            }
        }
        absentConfig.add("缺少的service配置:");
        for (String string : libInfo.serviceList) {
            if (apkInfo.serviceList.indexOf(string) < 0) {
                absentConfig.add(string);
            }
        }
        absentConfig.add("缺少的receiver配置:");
        for (String string : libInfo.receiverList) {
            if (apkInfo.receiverList.indexOf(string) < 0) {
                absentConfig.add(string);
            }
        }
        absentConfig.add("缺少的provider配置:");
        for (String string : libInfo.providerList) {
            if (apkInfo.providerList.indexOf(string) < 0) {
                absentConfig.add(string);
            }
        }
        absentConfig.add("缺少的meta-data配置:");
        for (String string : libInfo.metaList) {
            if (apkInfo.metaList.indexOf(string) < 0) {
                absentConfig.add(string);
            }
        }
        
        // 比对文件
        for (String string : libInfo.assetList) {
            if (apkInfo.assetList.indexOf(string) < 0) {
                absentFile.add(string);
            }
        }
        for (String string : libInfo.libList) {
            if (apkInfo.libList.indexOf(string) < 0) {
                absentFile.add(string);
            }
        }
        for (String string : libInfo.resList) {
            if (apkInfo.resList.indexOf(string) < 0) {
                absentFile.add(string);
            }
        }

        // 比对Value
        for (String string : libInfo.valueList) {
            if (apkInfo.valueList.indexOf(string) < 0) {
                absentValue.add(string);
            }
        }

        // 比对版本号
        sdkVersion = "apk版本号：" + apkInfo.sdkVersion + "\r\n" + "lib工程版本号：" + libInfo.sdkVersion;

        System.out.println("比对完成");

        writeResult(absentConfig, absentFile, absentValue, sdkVersion, otherCheck);
    }


    private static void writeResult(List<String> absentConfig, List<String> absentFile, List<String> absentValue,
                                    String sdkVersion, String otherCheck) {
        System.out.println("生成结果文件...");
        File result = new File(System.getProperty("user.dir") + File.separator + "result.txt");
        if (result.exists()) {
            result.delete();
        }
        try {
            result.createNewFile();
            FileWriter fw = new FileWriter(result);
            BufferedWriter writer = new BufferedWriter(fw);
            writer.write("============= 缺少的AndroidManifest配置 ============");
            writer.newLine();
            if (absentConfig.size() > 0) {
                for (String string : absentConfig) {
                    writer.write(string);
                    writer.newLine();
                }
            } else {
                writer.write("not found.");
                writer.newLine();
            }
            writer.newLine();
            writer.write("============= 缺少的资源文件 ============");
            writer.newLine();
            if (absentFile.size() > 0) {
                for (String string : absentFile) {
                    writer.write(string);
                    writer.newLine();
                }
            } else {
                writer.write("not found.");
                writer.newLine();
            }
            writer.newLine();
            writer.write("============= 缺少的Values文件夹下的资源 ============");
            writer.newLine();
            if (absentValue.size() > 0) {
                for (String string : absentValue) {
                    writer.write(string);
                    writer.newLine();
                }
            } else {
                writer.write("not found.");
                writer.newLine();
            }
            writer.newLine();
            writer.write("============= SDK版本号比对 ============");
            writer.newLine();
            writer.write(sdkVersion);
            writer.newLine();
            writer.write("============= 其他检查比对 ============");
            writer.newLine();
            if (otherCheck != null && otherCheck.length() > 0) {
                writer.write(otherCheck);
            } else {
                writer.write("not found.");
            }

            writer.flush();
            fw.close();
            writer.close();

            System.out.println("生成成功。");
            System.out.println("结果保存为result.txt，请点击查看。");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
