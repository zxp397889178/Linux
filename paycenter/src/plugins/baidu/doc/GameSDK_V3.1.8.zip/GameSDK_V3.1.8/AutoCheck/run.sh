java -Xmx256M -Djava.awt.headless=true -jar libs/apktool.jar d source.apk -o target
java -Djava.ext.dirs=./libs -jar bin.jar
rmdir target