import java.io.InputStream;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;

public class ManifestParser {

    private static final Namespace NS = Namespace.getNamespace("http://schemas.android.com/apk/res/android");

    public static void parse(InputStream in, PackageInfo info) {
        SAXBuilder saxBuilder = new SAXBuilder();
        try {
            Document document = saxBuilder.build(in);
            Element root = document.getRootElement();

            List listPermission = root.getChildren("uses-permission"); // 子节点是个集合
            for (Object object : listPermission) {
                String permission = ((Element) object).getAttributeValue("name", NS);
                if(permission.endsWith("permission.INSTALL_SHORTCUT")){
                	System.out.println("!!!重要 请移除创建快捷图标权限：" + permission);
                	continue;
                }
                System.out.println("permissionList加入:" + permission);
                info.permissionList.add(permission);
            }
            Element elemApp = root.getChild("application");
            List listActivity = elemApp.getChildren("activity");
            for (Object object : listActivity) {
                String activity = ((Element) object).getAttributeValue("name", NS);
                System.out.println("activityList加入:" + activity);
                info.activityList.add(activity);
            }
            List listService = elemApp.getChildren("service");
            for (Object object : listService) {
                String service = ((Element) object).getAttributeValue("name", NS);
                System.out.println("serviceList加入:" + service);
                info.serviceList.add(service);
            }
            List listReceiver = elemApp.getChildren("receiver");
            for (Object object : listReceiver) {
                String receiver = ((Element) object).getAttributeValue("name", NS);
                System.out.println("receiverList加入:" + receiver);
                info.receiverList.add(receiver);
            }
            List providers = elemApp.getChildren("provider");
            for (Object object : providers) {
                String provider = ((Element) object).getAttributeValue("name", NS);
                System.out.println("provider加入:" + provider);
                info.providerList.add(provider);
            }
            List metas = elemApp.getChildren("meta-data");
            for (Object object : metas) {
                String metadata = ((Element) object).getAttributeValue("name", NS);
                System.out.println("meta-data加入:" + metadata);
                info.providerList.add(metadata);
            }
            List listMeta = elemApp.getChildren("meta-data");
            for (Object object : listMeta) {
                String meta = ((Element) object).getAttributeValue("name", NS);
                if ("dksdk_ver".equals(meta)) {
                    info.sdkVersion = ((Element) object).getAttributeValue("value", NS);
                    System.out.println("info.sdkVersion:" + info.sdkVersion);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String checkScheme(InputStream in) {
        String result = "";
        SAXBuilder saxBuilder = new SAXBuilder();
        try {
            Document document = saxBuilder.build(in);
            Element root = document.getRootElement();
            String packagename = root.getAttributeValue("package");
            Element elemApp = root.getChild("application");
            List listActivity = elemApp.getChildren("activity");
            for (Object object : listActivity) {
                String name = ((Element) object).getAttributeValue("name", NS);
                if ("com.alipay.sdk.app.H5PayActivity".equals(name)) {
                    String scheme = getScheme((Element) object);
                    if (!("bdpsdk" + packagename).equals(scheme)) {
                        result += "支付宝Scheme配置错误，应配置为：" + "bdpsdk" + packagename + "\r\n";
                    }
                } else if ("com.baidu.platformsdk.pay.channel.qqwallet.QQPayActivity".equals(name)) {
                    String scheme = getScheme((Element) object);
                    if (!("qwallet" + packagename).equals(scheme)) {
                        result += "QQ钱包Scheme配置错误，应配置为：" + "qwallet" + packagename + "\r\n";
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            result = "检查Scheme配置失败，失败原因：" + e.getMessage();
        }
        return result;
    }

    public static String checkAuthorities(InputStream in) {
        String result = "";
        SAXBuilder saxBuilder = new SAXBuilder();
        try {
            Document document = saxBuilder.build(in);
            Element root = document.getRootElement();
            String packagename = root.getAttributeValue("package");
            Element elemApp = root.getChild("application");
            List listProvider = elemApp.getChildren("provider");
            for (Object object : listProvider) {
                String name = ((Element) object).getAttributeValue("name", NS);
                if ("com.duoku.platform.download.DownloadProvider".equals(name)) {
                    String authorities = getAuthorities((Element) object);
                    if (!(packagename).equals(authorities)) {
                        result += "多酷DownloadProvider配置错误，应配置为：" + packagename + "\r\n";
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            result = "检查Provider配置失败，失败原因：" + e.getMessage();
        }
        return result;
    }

    private static String getScheme(Element activity) {
        String scheme;
        try {
            Element intentFilter = activity.getChild("intent-filter");
            Element data = intentFilter.getChild("data");
            scheme = data.getAttributeValue("scheme", NS);
        } catch (Exception e) {
            scheme = null;
        }
        return scheme;
    }

    private static String getAuthorities(Element provider) {
        String authorities;
        try {
            authorities = provider.getAttributeValue("authorities", NS);
        } catch (Exception e) {
            authorities = null;
        }
        return authorities;
    }

}
