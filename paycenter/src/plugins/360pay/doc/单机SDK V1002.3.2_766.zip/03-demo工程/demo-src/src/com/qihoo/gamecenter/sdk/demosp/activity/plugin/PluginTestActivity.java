
package com.qihoo.gamecenter.sdk.demosp.activity.plugin;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo.gamecenter.sdk.demosp.R;
import com.qihoo.gamecenter.sdk.matrix.Matrix;
import com.qihoo.sdkplugging.host.ApkPluggingManager;
import com.qihoo.sdkplugging.host.PluggingCommandDef;
import com.qihoo.sdkplugging.host.PluggingInfo;

public class PluginTestActivity extends Activity {

	public final class ViewHolder {
		public TextView text;
	}

	private class PluginInfoAdapter extends BaseAdapter {
		private LayoutInflater mInflater;

		public PluginInfoAdapter(Context context) {
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return mPluginInfoList.size();
		}

		@Override
		public Object getItem(int position) {
			if (position < 0 || position >= mPluginInfoList.size())
				return null;

			return mPluginInfoList.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		/* 书中详细解释该方法 */
		@SuppressLint("InflateParams")
		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			ViewHolder holder;

			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.sdk_plugin_test_activity_listview, null);
				holder = new ViewHolder();
				holder.text = (TextView) convertView.findViewById(R.id.plugin_infomation);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			holder.text.setText((String) getItem(position));
			return convertView;
		}
	}

	private ListView mPluginListView = null;
	private TextView mPluginInfoView = null;
	private PluggingInfo mPluginInfo = null;

	private ArrayList<String> mPluginInfoList = new ArrayList<String>();
	
	private PluginInfoAdapter mPluginAdapter = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sdk_plugin_test_activity);
		initViews();
		
		ApkPluggingManager.getInstance().resetActivity(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	private void initViews() {

		this.findViewById(R.id.btn_shuaxin_plugin_info).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onShuaXinPluginInfo();
	            Toast.makeText(PluginTestActivity.this, "刷新插件信息完成", Toast.LENGTH_LONG).show();
			}
		});

		this.findViewById(R.id.btn_sp_get_plugin_info).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				getSpPluginInfo();
			}
		});

		this.findViewById(R.id.btn_open_plugin_1_float_wnd).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				openCommonPluginApkFloatWindow();
			}
		});

		this.findViewById(R.id.btn_close_plugin_1_float_wnd).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
//				CommonLogUtil.i("showenter", "click btn_close_plugin_1_float_wnd");
				closeCommonPluginApkFloatWindow();
			}
		});

		mPluginListView = (ListView) this.findViewById(R.id.plugin_listView);
		mPluginInfoView = (TextView) this.findViewById(R.id.plugin_info_txt);
		
		mPluginAdapter = new PluginInfoAdapter(this);
		mPluginListView.setAdapter(mPluginAdapter);
		
		onShuaXinPluginInfo();
	}
	
	private void getSpPluginInfo() {
		EditText et = ((EditText)this.findViewById(R.id.sp_plugin_num_editText));
		String num = et.getText().toString();
		if (num == null || num.length() <= 0) {
            Toast.makeText(this, "请输入正确的插件ID号", Toast.LENGTH_LONG).show();
			return;
		}
		
		Integer dstPluginId = Integer.valueOf(num);
		
		String version = (String)ApkPluggingManager.getInstance().doPluggingCommand(
				dstPluginId,
				PluggingCommandDef.SDK_PLUGIN_ID_HOST,
				PluggingCommandDef.COMMAND_ID_GET_VERSION_NAME,
				null);
		
		if (version == null || version.length() <= 0) {
            Toast.makeText(this, "获取插件信息失败，插件不存在 或 插件被禁用 或 插件初始化错误", Toast.LENGTH_LONG).show();
            return;
		}

        Toast.makeText(this, version, Toast.LENGTH_LONG).show();
		onShuaXinPluginInfo();
	}

	private void onShuaXinPluginInfo() {
		
		mPluginInfoList.clear();
		mPluginInfo = Matrix.getPluginInfomation(mPluginInfoList);

		if (mPluginInfo != null) {

			switch (mPluginInfo.mPluginInitErrCode) {
			case PluggingInfo.PLUGIN_INIT_ERR_CODE_SUCCESS:
				mPluginInfoView.setText("初始化插件成功，请查看是否有更新插件，下方为插件列表信息：");
				break;
			case PluggingInfo.PLUGIN_INIT_ERR_CODE_CLOSE_FROM_NET:
				mPluginInfoView.setText("初始化插件错误，云控关闭使用主插件，请查看是否有更新插件，下方为插件列表信息：");
				break;
			case PluggingInfo.PLUGIN_INIT_ERR_CODE_GET_PLUGIN_CONFIG_ERR:
				mPluginInfoView.setText("初始化插件错误，拉取插件配置信息失败，请查看是否有更新插件， 下方为插件列表信息：");
				break;
			case PluggingInfo.PLUGIN_INIT_ERR_CODE_INIT_MAIN_PLUGIN_ERR:
				mPluginInfoView.setText("初始化插件错误，初始化主插件错误，请查看是否有更新插件，下方为插件列表信息：");
				break;
			case PluggingInfo.PLUGIN_INIT_ERR_CODE_NONE:
				mPluginInfoView.setText("正在初始化插件，请点击【刷新按钮】取得最新初始化状态 ...");
				break;
			default:
				mPluginInfoView.setText("初始化插件未知错误！！！");
				break;
			}
		}
		
		mPluginAdapter.notifyDataSetChanged();
	}
	
	// 打开 通用插件 apk 中的 浮窗
	private void openCommonPluginApkFloatWindow() {
		Toast.makeText(this, "此功能已被屏蔽，如需打开，请联系开发", Toast.LENGTH_LONG).show();
	}

	private void closeCommonPluginApkFloatWindow() {
		Toast.makeText(this, "此功能已被屏蔽，如需打开，请联系开发", Toast.LENGTH_LONG).show();
	}
}
