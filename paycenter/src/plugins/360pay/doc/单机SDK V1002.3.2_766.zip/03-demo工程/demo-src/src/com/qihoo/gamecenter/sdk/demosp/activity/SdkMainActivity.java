
package com.qihoo.gamecenter.sdk.demosp.activity;

import com.qihoo.gamecenter.sdk.demosp.R;
import com.qihoo.gamecenter.sdk.demosp.payment.Constants;
import com.qihoo.gamecenter.sdk.matrix.Matrix;
import com.qihoo.gamecenter.sdk.protocols.ProtocolKeys;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
/**
 * 第一个activity，提供横屏和竖屏游戏的入口
 */
public class SdkMainActivity extends Activity implements View.OnClickListener {

    private Button portraitBtn;
    private Button landscapeBtn;
    private Button portraitTestBtn;
    private Button landscapeTestBtn;

    @SuppressLint("NewApi")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		
        //设置全屏
        getWindow().setFlags(
        		WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        setContentView(R.layout.sdk_main_activity);
        portraitBtn = (Button) findViewById(R.id.btn_portrait_game);
        landscapeBtn = (Button) findViewById(R.id.btn_landscape_game);
        portraitTestBtn = (Button) findViewById(R.id.btn_portrait_flow_test);
        landscapeTestBtn = (Button) findViewById(R.id.btn_landscape_flow_test);
        portraitBtn.setOnClickListener(this);
        landscapeBtn.setOnClickListener(this);
        portraitTestBtn.setOnClickListener(this);
        landscapeTestBtn.setOnClickListener(this);
        findViewById(R.id.btn_setpluginposition).setOnClickListener(this);
        
        /*portraitBtn.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);  
        landscapeBtn.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);  */
    }

    private void startPortraitSdkUserActivity() {
        Intent intent = new Intent(SdkMainActivity.this, PortraitSdkUserActivity.class);
        intent.putExtra(Constants.RIGHT_TO_LOGIN_TAG, getCheckBoxBoolean(R.id.isRightToLoginButton));
        intent.putExtra("is_from_360_market", getIntent().getBooleanExtra("is_from_360_market", false));
        startActivity(intent);
    }
    
    private boolean getCheckBoxBoolean(int id) {
        CheckBox cb = (CheckBox)findViewById(id);
        if (cb != null) {
            return cb.isChecked();
        }
        return false;
    }

    private void startLandscapeSdkUserActivity() {
        Intent intent = new Intent(SdkMainActivity.this, LandscapeSdkUserActivity.class);
        intent.putExtra(Constants.RIGHT_TO_LOGIN_TAG, getCheckBoxBoolean(R.id.isRightToLoginButton));
        intent.putExtra("is_from_360_market", getIntent().getBooleanExtra("is_from_360_market", false));
        startActivity(intent);
    }
    private void startSdkShowFlowTestActivity(boolean isLandScape) {
        Intent intent = new Intent(this, FlowTestLoginActivity.class);
        intent.putExtra(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);
        startActivity(intent);
        finish();
    }
    
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_portrait_game) {
            startPortraitSdkUserActivity();
        } else if (v.getId() == R.id.btn_landscape_game) {
            startLandscapeSdkUserActivity();
        }else if (v.getId() == R.id.btn_portrait_flow_test) {
            startSdkShowFlowTestActivity(false);
        }else if (v.getId() == R.id.btn_landscape_flow_test) {
            startSdkShowFlowTestActivity(true);
        }else if (v.getId() == R.id.btn_setpluginposition){
        	setFloatWindowPosition();
        	return;
        }
        this.finish();
    }
    
    /**
     * 设置浮窗的位置
     */
    protected void setFloatWindowPosition() {
    	EditText et = (EditText)findViewById(R.id.plugin_position_txt);
        String pos = et.getText().toString();
        int position = 1;//默认是左上为1
        if(!TextUtils.isEmpty(pos)){
        	try {
				position = Integer.parseInt(pos);
			} catch (Exception e) {
			}
        }
		Matrix.setFloatWindowPosition(position);
	}
}

