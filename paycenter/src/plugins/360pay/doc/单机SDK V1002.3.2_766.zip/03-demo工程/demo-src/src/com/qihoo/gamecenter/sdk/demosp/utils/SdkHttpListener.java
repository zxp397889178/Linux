
package com.qihoo.gamecenter.sdk.demosp.utils;

public interface SdkHttpListener {

    public void onResponse(String response);

    public void onCancelled();

}
