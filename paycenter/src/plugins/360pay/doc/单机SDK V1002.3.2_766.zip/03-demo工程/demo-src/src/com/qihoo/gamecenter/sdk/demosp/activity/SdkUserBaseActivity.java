package com.qihoo.gamecenter.sdk.demosp.activity;

import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Toast;

import com.qihoo.gamecenter.sdk.activity.ContainerActivity;
import com.qihoo.gamecenter.sdk.common.IDispatcherCallback;
import com.qihoo.gamecenter.sdk.demosp.R;
import com.qihoo.gamecenter.sdk.demosp.payment.Constants;
import com.qihoo.gamecenter.sdk.demosp.payment.QihooPayInfo;
import com.qihoo.gamecenter.sdk.demosp.utils.ProgressUtil;
import com.qihoo.gamecenter.sdk.demosp.utils.QihooUserInfo;
import com.qihoo.gamecenter.sdk.demosp.utils.QihooUserInfoListener;
import com.qihoo.gamecenter.sdk.demosp.utils.QihooUserInfoTask;
import com.qihoo.gamecenter.sdk.demosp.utils.Utils;
import com.qihoo.gamecenter.sdk.matrix.Matrix;
import com.qihoo.gamecenter.sdk.protocols.CPCallBackMgr.MatrixCallBack;
import com.qihoo.gamecenter.sdk.protocols.ProtocolConfigs;
import com.qihoo.gamecenter.sdk.protocols.ProtocolKeys;

/**
 * SdkUserBaseActivity这个基类，处理请求360SDK
 */
public abstract class SdkUserBaseActivity extends Activity{

    protected QihooUserInfo mQihooUserInfo;

    protected boolean mIsLandscape;

    protected String mAccessToken = null;

    private boolean mIsInOffline = false;

    /**
     * AccessToken是否有效
     */
    protected static boolean isAccessTokenValid = true;
    /**
     * QT是否有效
     */
    protected static boolean isQTValid = true;
    
    protected EditText appUserNameEdit;
    
    protected Intent mIntent;
    
    protected boolean mIsRightToLogin = false;
    
    protected EditText tokenIdEdit, orderIdEdit;
    protected Button tokenBtn;

    public void onGotUserInfo(QihooUserInfo userInfo) {

    }

    private void getUserInfo() {

        isAccessTokenValid = true;
        isQTValid = true;
        final QihooUserInfoTask mUserInfoTask = QihooUserInfoTask.newInstance();

        // 提示用户进度
        final ProgressDialog progress = ProgressUtil.show(this,
                R.string.get_user_title,
                R.string.get_user_message,
                new OnCancelListener() {

                    @Override
                    public void onCancel(DialogInterface dialog) {
                        if (mUserInfoTask != null) {
                            mUserInfoTask.doCancel();
                        }
                    }
                });

        // 请求应用服务器，用AccessToken换取UserInfo
        mUserInfoTask.doRequest(this, mAccessToken, Matrix.getAppKey(this), new QihooUserInfoListener() {

            @Override
            public void onGotUserInfo(QihooUserInfo userInfo) {
            	if(progress!=null){
            		 progress.dismiss();
            	}
                if (null == userInfo || !userInfo.isValid()) {
                    Toast.makeText(SdkUserBaseActivity.this, "从应用服务器获取用户信息失败", Toast.LENGTH_LONG).show();
                } else {
                    SdkUserBaseActivity.this.onGotUserInfo(userInfo);
                }
            }
        });
    }

    // 获取用来在demo上显示登录结果的字符串
    protected String getLoginResultText() {
        String result = "";

        try {
            if (mQihooUserInfo != null && mQihooUserInfo.isValid()) {
                JSONObject joUserInfo = new JSONObject();
                JSONObject joUserInfoData = new JSONObject();
                joUserInfo.put("data", joUserInfoData);
                joUserInfoData.put("name", mQihooUserInfo.getName());
                joUserInfoData.put("id", mQihooUserInfo.getId());
                joUserInfoData.put("avatar", mQihooUserInfo.getAvatar());
                joUserInfo.put("error_code", 0);
                result = "TokenInfo=" + mAccessToken +"\n\n" + "QihooUserInfo=" + joUserInfo.toString();
            }
        } catch (Throwable tr) {
            tr.printStackTrace();
        }

        return result;
    }

    // ---------------------------------回调接口------------------------------------
    protected boolean getLandscape(Context context) {
    	if (context == null) {
    		return false;
    	}
    	boolean landscape = (this.getResources().getConfiguration().orientation
    			== Configuration.ORIENTATION_LANDSCAPE);
    	return landscape;
    }
    protected MatrixCallBack mSDKCallback = new MatrixCallBack() {
		@Override
		public void execute(Context context, int functionCode, String functionParams) {
			if (functionCode == ProtocolConfigs.FUNC_CODE_SWITCH_ACCOUNT) {
				doSdkSwitchAccount(getLandscape(context));
			}else if (functionCode == ProtocolConfigs.FUNC_CODE_INITSUCCESS) {
				//这里返回成功之后才能调用SDK 其它接口
				// ...
				try {
					mIntent = getIntent();
					mIsRightToLogin = mIntent.getBooleanExtra(Constants.RIGHT_TO_LOGIN_TAG, false);
				} catch (Exception e) {
				}
				
				if(mIsRightToLogin){
					doSdkLogin(Utils.isScreenLandscape(SdkUserBaseActivity.this));
				}
			}else if (functionCode == ProtocolConfigs.FUNC_CODE_LOGIN){
				// 显示一下登录结果
	            Toast.makeText(SdkUserBaseActivity.this, functionParams, Toast.LENGTH_LONG).show();
	            mIsInOffline = false;
	            mQihooUserInfo = null;
//	            Log.d(TAG, "mLoginCallback, data is " + data);
	            // 解析access_token
	            mAccessToken = parseAccessTokenFromLoginResult(functionParams);

	            if (!TextUtils.isEmpty(mAccessToken)) {
	                // 需要去应用的服务器获取用access_token获取一下带qid的用户信息
	                getUserInfo();
	            } else {
	                Toast.makeText(SdkUserBaseActivity.this, "get access_token failed!", Toast.LENGTH_LONG).show();
	            }
			}else if (functionCode == ProtocolConfigs.FUNC_CODE_LOGINAFTER_REALNAME_CALLBACK){
				Toast.makeText(getApplicationContext(), "cp收到登录后实名制处理完后的回调："+functionParams, 0).show();
			}			
		}

    };

    // ---------------------------------调用360SDK接口------------------------------------

    @SuppressLint({ "InlinedApi", "NewApi" })
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        //设置无标题  
        requestWindowFeature(Window.FEATURE_NO_TITLE );  
        
        //设置全屏
        getWindow().setFlags(
        		WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        if (Build.VERSION.SDK_INT > 14) { 
        	Window _window = getWindow();
        	WindowManager.LayoutParams params = _window.getAttributes();
        	params.systemUiVisibility=View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN; 
        	_window.setAttributes(params);  
		}
        
    	if (Build.VERSION.SDK_INT >= 19 ) { 
		    getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS); 
		    getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION); 
    	}
    	
        /**
         * 此函数原来叫做：init，现在改名为：setActivity
         * 调用其他SDK接口之前必须先调用 setActivity
         * 注意：参数一定是主界面对应 activity 的 context，我们依赖这个 activity 来显示浮窗的，
         *       还有就是这个 activity 的 manifest 属性里添加 android:configChanges="orientation|keyboardHidden|screenSize"
         *       为了防止横竖屏切换时此 activity 重新创建，引起的一些问题。
         */
    	/**注意参数：
    	 * debugMode (第三个参数)：360SDK内部提供了自动检测SDK接入是否完整的功能和输出调试LOG的功能，默认为 false，这两项功能关闭，true则打开这两个功能，上线前请务必设置为 false
    	 * */
    	runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				Matrix.setActivity(SdkUserBaseActivity.this, mSDKCallback, false);				
			}
		});
        
    }

    @Override
    protected void onDestroy() {
        // 游戏退出前，不再调用SDK其他接口时，需要调用Matrix.destroy接口
        onDemoActivityDestroy(true);
    }

    protected void onDemoActivityDestroy(boolean releaseSdk) {
        // 请务必调用Matrix.destroy接口，
        // 如果不调用此接口，某些机型会发生窗口泄漏问题。
        if (releaseSdk) {
            Matrix.destroy(this);
        }
        super.onDestroy();
    }

    /*
     * 当用户要退出游戏时，需要调用SDK的退出接口。
     */
//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        switch (keyCode) {
//            case KeyEvent.KEYCODE_BACK:
//                doSdkQuit(mIsLandscape);
//                return true;
//            default:
//                return super.onKeyDown(keyCode, event);
//        }
//    }

    /**
     * 打开悬浮窗内容
     */
    protected void openFloatWindow() {
    	Matrix.openFloatWindow(this);
	}
    
    /**
     * 使用360SDK的登录接口
     *
     * @param isLandScape 是否横屏显示登录界面
     */
    protected void doSdkLogin(boolean isLandScape) {
        mIsInOffline = false;
        Intent intent = getLoginIntent(isLandScape);
        IDispatcherCallback callback = mLoginCallback;
        Matrix.execute(this, intent, callback);
    }
    
    // 实名注册
    protected void doOpenSdkRealName(QihooUserInfo usrinfo, boolean isLandScape) {
        if (!checkLoginInfo(usrinfo)) {
            return;
        }
        Intent intent = getRealNameRegisterIntent(isLandScape, (usrinfo != null) ? usrinfo.getId() : null);

        Matrix.invokeActivity(this, intent, new IDispatcherCallback() {
            @Override
            public void onFinished(String data) {
                Log.d("base_smtest", "RealNameRegisterCallback, data is " + data);
            	//存储一下展示过了
            }
        });
    }

    private Intent getRealNameRegisterIntent(boolean isLandScape, String qihooUserId) {

        Bundle bundle = new Bundle();
        // 界面相关参数，360SDK界面是否以横屏显示。
        bundle.putBoolean(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);

        // 必需参数，360账号id，整数。
        bundle.putString(ProtocolKeys.QIHOO_USER_ID, qihooUserId);

        // 可选参数，登录界面的背景图片路径，必须是本地图片路径
        bundle.putString(ProtocolKeys.UI_BACKGROUND_PICTRUE, "");

        // 必需参数，使用360SDK的实名注册模块。
        
        bundle.putInt(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_REAL_NAME_REGISTER);
        
        Intent intent = new Intent(this, ContainerActivity.class);
        intent.putExtras(bundle);
        return intent;
    }

    /**
     * 使用360SDK的切换帐号账号接口
     *
     * @param isLandScape 是否横屏显示登录界面
     */
    protected void doSdkSwitchAccount(boolean isLandScape) {
        Intent intent = getSwitchAccountIntent(isLandScape);
        IDispatcherCallback callback = mAccountSwitchCallback;
        Matrix.invokeActivity(this, intent, callback);
    }

    // -----------------------------------登录选项-------------------------------------

    private boolean getCheckBoxBoolean(int id) {
        CheckBox cb = (CheckBox)findViewById(id);
        if (cb != null) {
            return cb.isChecked();
        }
        return false;
    }

    /**
     * 生成调用360SDK登录接口的Intent
     * @param isLandScape 是否横屏
     * @return intent
     */
    private Intent getLoginIntent(boolean isLandScape) {

        Intent intent = new Intent(this, ContainerActivity.class);

        // 界面相关参数，360SDK界面是否以横屏显示。
        intent.putExtra(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);

        // 必需参数，使用360SDK的登录模块。
        intent.putExtra(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_LOGIN);

        // 可选参数，是否在自动登录的过程中显示切换帐号按钮
        intent.putExtra(ProtocolKeys.IS_SHOW_AUTOLOGIN_SWITCH, getCheckBoxBoolean(R.id.isShowSwitchButton));

        //-- 以下参数仅仅针对自动登录过程的控制
        // 可选参数，自动登录过程中是否不展示任何UI，默认展示。
        intent.putExtra(ProtocolKeys.IS_AUTOLOGIN_NOUI, getCheckBoxBoolean(R.id.isAutoLoginHideUI));

        return intent;
    }

    /***
     * 生成调用360SDK切换帐号接口的Intent
     *
     * @param isLandScape 是否横屏
     * @return Intent
     */
    private Intent getSwitchAccountIntent(boolean isLandScape) {

        Intent intent = new Intent(this, ContainerActivity.class);
        // 可选参数，是否在自动登录的过程中显示切换帐号按钮
        intent.putExtra(ProtocolKeys.IS_SHOW_AUTOLOGIN_SWITCH, getCheckBoxBoolean(R.id.isShowSwitchButton));
        
        // 必须参数，360SDK界面是否以横屏显示。
        intent.putExtra(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);

        // 必需参数，使用360SDK的切换帐号模块。
        intent.putExtra(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_SWITCH_ACCOUNT);

        return intent;
    }

    // ---------------------------------360SDK接口的回调-----------------------------------

    // 登录、注册的回调
    private IDispatcherCallback mLoginCallback = new IDispatcherCallback() {

        @Override
        public void onFinished(String data) {
            // press back
            if (isCancelLogin(data)) {
                return;
            }
            // 显示一下登录结果
            Toast.makeText(SdkUserBaseActivity.this, data, Toast.LENGTH_LONG).show();
            mIsInOffline = false;
            mQihooUserInfo = null;
//            Log.d(TAG, "mLoginCallback, data is " + data);
            // 解析access_token
            mAccessToken = parseAccessTokenFromLoginResult(data);

            if (!TextUtils.isEmpty(mAccessToken)) {
                // 需要去应用的服务器获取用access_token获取一下带qid的用户信息
                getUserInfo();
            } else {
                Toast.makeText(SdkUserBaseActivity.this, "get access_token failed!", Toast.LENGTH_LONG).show();
            }
        }
    };


    // 切换帐号的回调
    private IDispatcherCallback mAccountSwitchCallback = new IDispatcherCallback() {

        @Override
        public void onFinished(String data) {
            // press back
            if (isCancelLogin(data)) {
                return;
            }
            if(data!=null){
            	 // 显示一下登录结果
                Toast.makeText(SdkUserBaseActivity.this, data, Toast.LENGTH_LONG).show();
            }
            // 解析access_token
            mAccessToken = parseAccessTokenFromLoginResult(data);

            if (!TextUtils.isEmpty(mAccessToken)) {
                // 需要去应用的服务器获取用access_token获取一下带qid的用户信息
                getUserInfo();
            } else {
                Toast.makeText(SdkUserBaseActivity.this, "get access_token failed!", Toast.LENGTH_LONG).show();
            }
        }
    };

    private boolean isCancelLogin(String data) {
        try {
            JSONObject joData = new JSONObject(data);
            int errno = joData.optInt("errno", -1);
            if (-1 == errno) {
                Toast.makeText(SdkUserBaseActivity.this, data, Toast.LENGTH_LONG).show();
                return true;
            }
        } catch (Exception e) {}
        return false;
    }


 // ------------------注销登录----------------
    protected void doSdkLogout(QihooUserInfo usrInfo){
//    	1、该注释api部分用于检测当前用户是否是登陆状态，CP可以按照自己的需要灵活使用或者自定义逻辑判断用户登录状态。
//    	if(!checkLoginInfo(usrInfo)) {
//            return;
//        }
        Intent intent = getLogoutIntent();
        Matrix.execute(this, intent, new IDispatcherCallback() {
            @Override
            public void onFinished(String data) {
//            	2、如果用户是未登录状态，则直接调用“注销登陆”接口 会返回注销登陆失败的结果，请CP根据自己的业务处理该处逻辑即可。
                Toast.makeText(SdkUserBaseActivity.this, data, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private Intent getLogoutIntent(){

        /*
         * 必须参数：
         *  function_code : 必须参数，表示调用SDK接口执行的功能
        */
        Intent intent = new Intent();
        intent.putExtra(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_LOGOUT);
        return intent;
    }

    private boolean checkLoginInfo(QihooUserInfo info ){
        if(Matrix.isOnline()){
        	if(null == info || !info.isValid()){
                Toast.makeText(this,  "需要登录才能执行此操作" , Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    private boolean checkLoginInfo(QihooUserInfo info,String errMsg){
        if(Matrix.isOnline()){
        	if(null == info || !info.isValid()){
                Toast.makeText(this, (TextUtils.isEmpty(errMsg) ? "需要登录才能执行此操作" :errMsg), Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    //--------------分享--------------
    private String shareType = ProtocolKeys.SHARE_DEFAULT_STRING;
    private String shareMethod = ProtocolConfigs.SHARE_TYPE_URL;
    @SuppressLint("InflateParams") 
    protected void doSdkShare(QihooUserInfo usrInfo, final boolean bLandScape){
        /*if(!checkLoginInfo(usrInfo)) {  //产品要求，分享不是强登陆需求
            return;
        }*/

        AlertDialog.Builder ab = new AlertDialog.Builder(SdkUserBaseActivity.this);
        shareType = ProtocolKeys.SHARE_DEFAULT_STRING;
        LinearLayout llt = (LinearLayout)SdkUserBaseActivity.this.getLayoutInflater().inflate(R.layout.shared_layout, null);
        final EditText etTitle = (EditText)llt.findViewById(R.id.edit_share_title);
        final EditText etDesc = (EditText)llt.findViewById(R.id.edit_share_desc); 
        final EditText etIcon = (EditText)llt.findViewById(R.id.edit_share_icon);
        final EditText etUrl = (EditText)llt.findViewById(R.id.edit_share_url);
        final EditText etImg = (EditText)llt.findViewById(R.id.edit_share_img);
         
        ScrollView scollView = (ScrollView)llt.findViewById(R.id.scrollView1);
        if (null == scollView) {
			return;
		}
        RadioGroup group = (RadioGroup)scollView.findViewById(R.id.radioGroup1);
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { 
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) { 
				if (null == group || checkedId <= 0) {
					return;
				}
				if (R.id.radio0 == checkedId) {
					shareType = ProtocolKeys.SHARE_DEFAULT_STRING;
				}else if (R.id.radio1 == checkedId) {
					shareType = ProtocolKeys.SHARE_2_WX_TIMELINE;
				}else if (R.id.radio2 == checkedId) {
					shareType = ProtocolKeys.SHARE_2_WX_FRIENDS;
				}else if (R.id.radio3 == checkedId) {
					shareType = ProtocolKeys.SHARE_2_QQ_SPACE;
				}else if (R.id.radio4 == checkedId) {
					shareType = ProtocolKeys.SHARE_2_QQ_FRIENDS;
				}else if (R.id.radio6 == checkedId) {
					shareType = ProtocolKeys.SHARE_2_CLIP_BOARD;
				}
			}
		});
        
        final RadioGroup group1 = (RadioGroup)scollView.findViewById(R.id.radioGroup2);
        group1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { 
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) { 
				if (null == group || checkedId <= 0) {
					return;
				}
				if (R.id.radio20 == checkedId) {
					shareMethod = ProtocolConfigs.SHARE_TYPE_URL;
				}else if (R.id.radio21 == checkedId) {
					shareMethod = ProtocolConfigs.SHARE_TYPE_IMG;
				}
			}
		});
        
        ab.setView(llt);
        ab.setTitle("输入分享内容");
        ab.setView(llt);
        ab.setPositiveButton("确定", new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
            	if(group1.getCheckedRadioButtonId() == R.id.radio20){
            		shareMethod = ProtocolConfigs.SHARE_TYPE_URL;
            	}else if(group1.getCheckedRadioButtonId() == R.id.radio21){
            		shareMethod = ProtocolConfigs.SHARE_TYPE_IMG;
            	}
                Intent intent = getShareIntent(shareType,
                		getTextStr(etTitle),
                		getTextStr(etDesc),
                				getTextStr(etIcon), 
                						getTextStr(etUrl),
                								getTextStr(etImg),bLandScape);
                
                Matrix.invokeActivity(SdkUserBaseActivity.this, intent, new IDispatcherCallback() {
                    @Override
                    public void onFinished(String data) {
                        if (null == data) {
                            return;
                        }
                        Toast.makeText(SdkUserBaseActivity.this, data, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        ab.show();
    }
    
    private String getTextStr(EditText txt){
    	if(TextUtils.isEmpty(txt.getHint().toString())){
    		return txt.getText().toString();
    	}
    	return txt.getHint().toString();
    }


    private Intent getShareIntent(String shareType,String title, String desc, String icon, String url,String pic, boolean isLandScape){
        Intent intent = new Intent();
        /*
         * 必须参数：
         *  shareType:分享类型
         *  function_code : 必须参数，标识通知SDK要执行的功能
         *  screen_orientation : 可选参数，指定横竖屏，默认为横屏 
         *  share_method ：分享方式，链接分享还是图片分享
         *  share_title : 必须参数，分享的标题
         *  share_desc : 必须参数，分享的描述 
         *  share_icon : 必选参数，分享的icon路径
         *  share_img ：分析图片
         *  url : 必选参数，分享的URL
        */
        intent.putExtra(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_SHARE);
        intent.putExtra(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);  
        intent.putExtra(ProtocolKeys.SHARE_TYPE, shareType);
        intent.putExtra(ProtocolKeys.SHARE_METHOD, shareMethod);
        intent.putExtra(ProtocolKeys.SHARE_TITLE, title);
        intent.putExtra(ProtocolKeys.SHARE_DESC, desc); 
        intent.putExtra(ProtocolKeys.SHARE_ICON, icon);
        intent.putExtra(ProtocolKeys.SHARE_URL, url);
        intent.putExtra(ProtocolKeys.SHARE_PIC, pic);
        return intent;
    }
    
    private String parseAccessTokenFromLoginResult(String loginRes) {
        try {
            JSONObject joRes = new JSONObject(loginRes);
            JSONObject joData = joRes.getJSONObject("data");
            return joData.getString("access_token");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 使用360SDK的论坛接口
     *
     * @param isLandScape 是否横屏显示支付界面
     */
    protected void doSdkBBS(QihooUserInfo usrinfo, boolean isLandScape) {
        if (!checkLoginInfo(usrinfo,"登录后才能使用论坛功能")) {
            return;
        }

        if (!Utils.isNetAvailable(this)) {
            Toast.makeText(this, "网络不可用", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = getBBSIntent(isLandScape);

        Matrix.invokeActivity(this, intent, null);
    }


    /**
     * 使用360SDK的客服接口
     *
     * @param isLandScape 是否横屏显示支付界面
     */
    protected void doOpenKefu(QihooUserInfo usrinfo, boolean isLandScape) {
        if (!checkLoginInfo(usrinfo,"登录后才能使用客服功能")) {
            return;
        }

        if (!Utils.isNetAvailable(this)) {
            Toast.makeText(this, "网络不可用", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = getKefuIntent(isLandScape);
        Matrix.invokeActivity(this, intent, null);
    }


    /***
     * 生成调用360SDK论坛接口的Intent
     *
     * @param isLandScape
     * @return Intent
     */
    private Intent getBBSIntent(boolean isLandScape) {

        Bundle bundle = new Bundle();

        // 界面相关参数，360SDK界面是否以横屏显示。
        bundle.putBoolean(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);

        // 必需参数，使用360SDK的论坛模块。
        bundle.putInt(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_BBS);

        Intent intent = new Intent(this, ContainerActivity.class);
        intent.putExtras(bundle);

        return intent;
    }

    /***
     * 生成调用360SDK客服接口的Intent
     *
     * @param isLandScape
     * @return Intent
     */
    private Intent getKefuIntent(boolean isLandScape) {

        Bundle bundle = new Bundle();

        // 界面相关参数，360SDK界面是否以横屏显示。
        bundle.putBoolean(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);

        // 必需参数，使用360SDK的客服模块。
        bundle.putInt(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_KEFU);

        Intent intent = new Intent(this, ContainerActivity.class);
        intent.putExtras(bundle);

        return intent;
    }


    /**
     * 使用360SDK的退出接口
     *
     * @param isLandScape 是否横屏显示支付界面
     */
    protected void doSdkQuit(boolean isLandScape) {

        Bundle bundle = new Bundle();

        // 界面相关参数，360SDK界面是否以横屏显示。
        bundle.putBoolean(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);

        // 必需参数，使用360SDK的退出模块。
        bundle.putInt(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_QUIT);

        // 可选参数，登录界面的背景图片路径，必须是本地图片路径
        bundle.putString(ProtocolKeys.UI_BACKGROUND_PICTRUE, "");

        Intent intent = new Intent(this, ContainerActivity.class);
        intent.putExtras(bundle);

        Matrix.invokeActivity(this, intent, mQuitCallback);
    }

    // 退出的回调
    private IDispatcherCallback mQuitCallback = new IDispatcherCallback() {

        @Override
        public void onFinished(String data) {
//            Log.d(TAG, "mQuitCallback, data is " + data);
            JSONObject json;
            try {
                json = new JSONObject(data);
                int which = json.optInt("which", -1);
                String label = json.optString("label");

                Toast.makeText(SdkUserBaseActivity.this,
                        "按钮标识：" + which + "，按钮描述:" + label, Toast.LENGTH_LONG)
                        .show();

                switch (which) {
                    case 0: // 用户关闭退出界面
                        return;
                    default:// 退出游戏
                        finish();
                        return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    };

    /**
     * 本方法中的callback实现仅用于测试, 实际使用由游戏开发者自己处理
     *
     * @param accessToken
     * @param userInfo 奇虎360用户信息
     */
    protected void doSdkAntiAddictionQuery(String accessToken, QihooUserInfo userInfo) {

        if (!checkLoginInfo(userInfo)) {
            return;
        }

        Intent intent = getAntAddictionIntent(accessToken, (userInfo != null) ? userInfo.getId() : null);
        Matrix.execute(this, intent, new IDispatcherCallback() {

            @Override
            public void onFinished(String data) {
                Log.d("base_smtest", data);
                if (!TextUtils.isEmpty(data)) {
                    try {
                        JSONObject resultJson = new JSONObject(data);
                        int errorCode = resultJson.optInt("error_code");
                        if (errorCode == 0) {
                            JSONObject contentData = resultJson.getJSONObject("content");
                            if(contentData != null) {
                                // 保存登录成功的用户名及密码
                                JSONArray retData = contentData.getJSONArray("ret");
//                                Log.d(TAG, "ret data = " + retData);
                                if(retData != null && retData.length() > 0) {
                                    int status = retData.getJSONObject(0).optInt("status");
//                                    Log.d(TAG, "status = " + status);
                                    switch (status) {

                                        case 0:  // 查询结果:无此用户数据
                                            Toast.makeText(SdkUserBaseActivity.this,
                                                    getString(R.string.anti_addiction_query_result_0),
                                                    Toast.LENGTH_LONG).show();
                                            break;

                                        case 1:  // 查询结果:未成年
                                            Toast.makeText(SdkUserBaseActivity.this,
                                                    getString(R.string.anti_addiction_query_result_1),
                                                    Toast.LENGTH_LONG).show();
                                            break;

                                        case 2:  // 查询结果:已成年
                                            Toast.makeText(SdkUserBaseActivity.this,
                                                    getString(R.string.anti_addiction_query_result_2),
                                                    Toast.LENGTH_LONG).show();
                                            break;

                                        default:
                                            break;
                                    }
                                    return;
                                }
                            }
                        } else {
                            Toast.makeText(SdkUserBaseActivity.this,
                                    resultJson.optString("error_msg"), Toast.LENGTH_SHORT).show();
                            return;
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(SdkUserBaseActivity.this,
                            getString(R.string.anti_addiction_query_exception),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private Intent getAntAddictionIntent(String token, String qid) {
        Bundle bundle = new Bundle();

        // 必需参数，用户access token，要使用注意过期和刷新问题，最大64字符。
        bundle.putString(ProtocolKeys.ACCESS_TOKEN, token);

        // 必需参数，360账号id，整数。
        bundle.putString(ProtocolKeys.QIHOO_USER_ID, qid);

        // 必需参数，使用360SDK的防沉迷查询模块。
        bundle.putInt(ProtocolKeys.FUNCTION_CODE, ProtocolConfigs.FUNC_CODE_ANTI_ADDICTION_QUERY);

        Intent intent = new Intent(this, ContainerActivity.class);
        intent.putExtras(bundle);
        return intent;
    }


    protected boolean mGetUserInfoFlag = false;
    
    /**
     * 角色信息采集接口
     */
    protected void doSdkGetUserInfoByCP() {
    	
    	//----------------------------模拟数据------------------------------
    	//帐号余额
        JSONArray balancelist = new JSONArray();
        JSONObject balance1 = new JSONObject();
        JSONObject balance2 = new JSONObject();

        //好友关系
        JSONArray friendlist = new JSONArray();
        JSONObject friend1 = new JSONObject();
        JSONObject friend2 = new JSONObject();

        //排行榜列表
        JSONArray ranklist = new JSONArray();
        JSONObject rank1 = new JSONObject();
        JSONObject rank2 = new JSONObject();

        try {
            balance1.put("balanceid","1");
            balance1.put("balancename","bname1");
            balance1.put("balancenum","200");
            balance2.put("balanceid","2");
            balance2.put("balancename","bname2");
            balance2.put("balancenum","300");
            balancelist.put(balance1).put(balance2);

            friend1.put("roleid","1");
            friend1.put("intimacy","0");
            friend1.put("nexusid","300");
            friend1.put("nexusname","情侣");
            friend2.put("roleid","2");
            friend2.put("intimacy","0");
            friend2.put("nexusid","600");
            friend2.put("nexusname","情侣");
            friendlist.put(friend1).put(friend2);

            rank1.put("listid","1");
            rank1.put("listname","listname1");
            rank1.put("num","num1");
            rank1.put("coin","coin1");
            rank1.put("cost","cost1");
            rank2.put("listid","2");
            rank2.put("listname","listname2");
            rank2.put("num","num2");
            rank2.put("coin","coin2");
            rank2.put("cost","cost2");
            ranklist.put(rank1).put(rank2);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        HashMap<String, String> eventParams=new HashMap<String, String>();

        eventParams.put("type","enterServer");  //（必填）角色状态（enterServer（登录），levelUp（升级），createRole（创建角色），exitServer（退出））
        eventParams.put("zoneid","2");  //（必填）游戏区服ID
        eventParams.put("zonename","测试服");  //（必填）游戏区服名称
        eventParams.put("roleid","123456");  //（必填）玩家角色ID
        eventParams.put("rolename","冷雨夜风");  //（必填）玩家角色名
        eventParams.put("professionid","1");  //（必填）职业ID
        eventParams.put("profession","战士");  //（必填）职业名称
//        eventParams.put("gender","男");  //（必填）性别
//        eventParams.put("professionroleid","0");  //（选填）职业称号ID
//        eventParams.put("professionrolename","无");  //（选填）职业称号
        eventParams.put("rolelevel","30");  //（必填）玩家角色等级
//        eventParams.put("power","120000");  //（必填）战力数值
        eventParams.put("vip","5");  //（必填）当前用户VIP等级
        eventParams.put("balance",balancelist.toString());  //（必填）帐号余额
        eventParams.put("partyid","100");  //（必填）所属帮派帮派ID
        eventParams.put("partyname","王者依旧");  //（必填）所属帮派名称
//        eventParams.put("partyroleid","1");  //（必填）帮派称号ID
//        eventParams.put("partyrolename","会长");  //（必填）帮派称号名称
//        eventParams.put("friendlist",friendlist.toString());  //（必填）好友关系
        eventParams.put("ranking",ranklist.toString());  //（选填）排行榜列表
        //参数eventParams相关的 key、value键值对 相关具体使用说明，请参考文档。
        //----------------------------模拟数据------------------------------
    	Matrix.statEventInfo(getApplicationContext(), eventParams);
    }
    

    // payment begin
    /***
     * @param moneyAmount 金额数，使用者可以自由设定数额。金额数为100的整数倍，360SDK运行定额支付流程；
     *            金额数为0，360SDK运行不定额支付流程。
     * @return QihooPay
     */
    private QihooPayInfo getQihooPay(String moneyAmount) {

        String qihooUserId = (mQihooUserInfo != null) ? mQihooUserInfo.getId() : null;

        // 创建QihooPay
        QihooPayInfo qihooPay = new QihooPayInfo();
        qihooPay.setQihooUserId(qihooUserId);
        qihooPay.setMoneyAmount(moneyAmount);
        qihooPay.setExchangeRate(Constants.DEMO_PAY_EXCHANGE_RATE);

        qihooPay.setProductName(getString(R.string.demo_pay_product_name));
        qihooPay.setProductId(Constants.DEMO_PAY_PRODUCT_ID);

        qihooPay.setNotifyUri(Constants.DEMO_APP_SERVER_NOTIFY_URI);

        qihooPay.setAppName(getString(R.string.demo_pay_app_name));
        qihooPay.setAppUserName(getString(R.string.demo_pay_app_user_name));
        qihooPay.setAppUserId(Constants.DEMO_PAY_APP_USER_ID);

        // 可选参数
        qihooPay.setAppExt1(getString(R.string.demo_pay_app_ext1));
        qihooPay.setAppExt2(getString(R.string.demo_pay_app_ext2));
        qihooPay.setAppOrderId("");

        return qihooPay;
    }

    protected QihooPayInfo getQihooPayInfo(boolean isFixed, int functionCode) {
        QihooPayInfo payInfo = null;
        //收银台可以使用定额支付或者不定额支付。
        if(functionCode==ProtocolConfigs.FUNC_CODE_PAY){
        	 payInfo = getQihooPay(getPayAmountForAliOrWeiXin());
        }
        //微信或者支付宝 支付 必须使用定额支付。
        if(functionCode==ProtocolConfigs.FUNC_CODE_WEIXIN_PAY||functionCode==ProtocolConfigs.FUNC_CODE_ALI_PAY){
                payInfo = getQihooPay(getPayAmountForAliOrWeiXin());
        }
        return payInfo;
    }

    /***
     * 生成调用360SDK支付接口的Intent
     *
     * @param isLandScape
     * @param pay
     * @return Intent
     */
    protected Intent getPayIntent(boolean isLandScape, QihooPayInfo pay,int functionCode) {
    	EditText appuseridet = (EditText)findViewById(R.id.et_input_appuserid);
    	EditText appOrderidet = (EditText) findViewById(R.id.et_input_orderid);
        Bundle bundle = new Bundle();

        // 界面相关参数，360SDK界面是否以横屏显示。
        bundle.putBoolean(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, isLandScape);

        // *** 以下非界面相关参数 ***

        // 设置QihooPay中的参数。

        // 设置QihooPay中的参数。
        if(getCheckBoxBoolean(R.id.send_qid)){
        	bundle.putString(ProtocolKeys.QIHOO_USER_ID, pay.getQihooUserId());
        }

        // 必需参数，所购买商品金额, 以分为单位。金额大于等于100分，360SDK运行定额支付流程； 金额数为0，360SDK运行不定额支付流程。
        bundle.putString(ProtocolKeys.AMOUNT, pay.getMoneyAmount());

        // 必需参数，所购买商品名称，应用指定，建议中文，最大10个中文字。
        bundle.putString(ProtocolKeys.PRODUCT_NAME, pay.getProductName());

        // 必需参数，购买商品的商品id，应用指定，最大16字符。
        bundle.putString(ProtocolKeys.PRODUCT_ID, pay.getProductId());

        // 必需参数，应用方提供的支付结果通知uri，最大255字符。360服务器将把支付接口回调给该uri，具体协议请查看文档中，支付结果通知接口–应用服务器提供接口。
        bundle.putString(ProtocolKeys.NOTIFY_URI, pay.getNotifyUri());

        // 必需参数，游戏或应用名称，最大16中文字。
        bundle.putString(ProtocolKeys.APP_NAME, pay.getAppName());

        // 必需参数，应用内的用户名，如游戏角色名。 若应用内绑定360账号和应用账号，则可用360用户名，最大16中文字。（充值不分区服，
        // 充到统一的用户账户，各区服角色均可使用）。
        
        if(appUserNameEdit != null && !TextUtils.isEmpty(appUserNameEdit.getEditableText().toString())){
        	bundle.putString(ProtocolKeys.APP_USER_NAME, appUserNameEdit.getEditableText().toString());
        }else{
        	bundle.putString(ProtocolKeys.APP_USER_NAME, pay.getAppUserName());
        }
        
        if(appuseridet!=null && !TextUtils.isEmpty(appuseridet.getEditableText().toString())){
        	// 必需参数，应用内的用户id。
            // 若应用内绑定360账号和应用账号，充值不分区服，充到统一的用户账户，各区服角色均可使用，则可用360用户ID最大32字符。
            bundle.putString(ProtocolKeys.APP_USER_ID, appuseridet.getEditableText().toString());
        }else{
        	// 必需参数，应用内的用户id。
            // 若应用内绑定360账号和应用账号，充值不分区服，充到统一的用户账户，各区服角色均可使用，则可用360用户ID最大32字符。
            bundle.putString(ProtocolKeys.APP_USER_ID, pay.getAppUserId());
        }

        // 可选参数，应用扩展信息1，原样返回，最大255字符。
        bundle.putString(ProtocolKeys.APP_EXT_1, pay.getAppExt1());

        // 可选参数，应用扩展信息2，原样返回，最大255字符。
        bundle.putString(ProtocolKeys.APP_EXT_2, pay.getAppExt2());

        if(appOrderidet!=null && !TextUtils.isEmpty(appOrderidet.getEditableText().toString())){
        	// 可选参数，应用订单号，应用内必须唯一，最大32字符。
            bundle.putString(ProtocolKeys.APP_ORDER_ID, appOrderidet.getEditableText().toString());
        }else{
        	// 可选参数，应用订单号，应用内必须唯一，最大32字符。
            bundle.putString(ProtocolKeys.APP_ORDER_ID, pay.getAppOrderId());
            
//        	//此为测试代码，CP需要使用自己的app_order_id
//        	//此app_order_id仅仅是为了海马云支付测试使用，不是真正产生的。
//        	//2018年10月26日 by weichenglin
//        	if ("com.qihoo.gamecenter.sdk.demosp".equals(getApplicationContext().getPackageName())){
//        		orderId = System.currentTimeMillis() + "";
//        	}
        }

        // 必需参数，使用360SDK的支付模块:CP可以根据需求选择使用 带有收银台的支付模块 或者 直接调用微信支付模块或者直接调用支付宝支付模块。
        //functionCode 对应三种支付模块：
        //ProtocolConfigs.FUNC_CODE_PAY;//表示 带有360收银台的支付模块。
        //ProtocolConfigs.FUNC_CODE_WEIXIN_PAY;//表示 微信支付模块。
        //ProtocolConfigs.FUNC_CODE_ALI_PAY;//表示支付宝支付模块。
        bundle.putInt(ProtocolKeys.FUNCTION_CODE,functionCode);
        
        Intent intent = new Intent(this, ContainerActivity.class);
        intent.putExtras(bundle);

        return intent;
    }

    protected String getPayAmountForAliOrWeiXin(){
    	EditText et_input_amount = (EditText) findViewById(R.id.et_input_amount);
    	String amount = et_input_amount.getEditableText().toString();
    	return amount;
    }
    
    protected void doServerPay(Intent payIntent, QihooUserInfo userinfo, boolean isLandScape, int functionCode){
    	if (!checkLoginInfo(userinfo)) {
            return;
        }
    	if (payIntent == null){
    		Toast.makeText(getApplicationContext(), "请先点击<获取TOKENID>按钮", Toast.LENGTH_SHORT).show();
    		return;
    	}
    	
    	String tokenIdS = tokenIdEdit.getEditableText().toString();
    	String orderIdS = orderIdEdit.getEditableText().toString();
    	if(TextUtils.isEmpty(tokenIdS) || TextUtils.isEmpty(orderIdS)){
    		Toast.makeText(getApplicationContext(), "参数有误", Toast.LENGTH_SHORT).show();
    		return;
    	}

        if(!isAccessTokenValid) {
            Toast.makeText(SdkUserBaseActivity.this, R.string.access_token_invalid, Toast.LENGTH_SHORT).show();
            return;
        }
        if(!isQTValid) {
            Toast.makeText(SdkUserBaseActivity.this, R.string.qt_invalid, Toast.LENGTH_SHORT).show();
            return;
        }
        
        //服务器下单的两个相关字段
        payIntent.putExtra(ProtocolKeys.TOKEN_ID, tokenIdS);
        payIntent.putExtra(ProtocolKeys.ORDER_TOKEN, orderIdS);

        // 必需参数，使用360SDK的支付模块:CP可以根据需求选择使用 带有收银台的支付模块 或者 直接调用微信支付模块或者直接调用支付宝支付模块。
        //functionCode 对应三种支付模块：
        //ProtocolConfigs.FUNC_CODE_PAY;//表示 带有360收银台的支付模块。
        //ProtocolConfigs.FUNC_CODE_WEIXIN_PAY;//表示 微信支付模块。
        //ProtocolConfigs.FUNC_CODE_ALI_PAY;//表示支付宝支付模块。
        payIntent.putExtra(ProtocolKeys.FUNCTION_CODE,functionCode);
        
        // 启动接口
        Matrix.invokeActivity(SdkUserBaseActivity.this, payIntent, mPayCallback);
    }
    
    protected void doSdkPay(QihooUserInfo usrinfo, boolean isLandScape,int functionCode) {

        if (!checkLoginInfo(usrinfo)) {
            return;
        }

        if(Matrix.isOnline()){
        	if(!isAccessTokenValid) {
                Toast.makeText(SdkUserBaseActivity.this, R.string.access_token_invalid, Toast.LENGTH_SHORT).show();
                return;
            }
            if(!isQTValid) {
                Toast.makeText(SdkUserBaseActivity.this, R.string.qt_invalid, Toast.LENGTH_SHORT).show();
                return;
            }
        }

        boolean isFixed = getCheckBoxBoolean(R.id.isPayFixed);
        // 支付基础参数
        QihooPayInfo payInfo = getQihooPayInfo(isFixed,functionCode);
        Intent intent = getPayIntent(isLandScape, payInfo,functionCode);
        
        // 必需参数，使用360SDK的支付模块:CP可以根据需求选择使用 带有收银台的支付模块 或者 直接调用微信支付模块或者直接调用支付宝支付模块。
        //functionCode 对应三种支付模块：
        //ProtocolConfigs.FUNC_CODE_PAY;//表示 带有360收银台的支付模块。
        //ProtocolConfigs.FUNC_CODE_WEIXIN_PAY;//表示 微信支付模块。
        //ProtocolConfigs.FUNC_CODE_ALI_PAY;//表示支付宝支付模块。
        intent.putExtra(ProtocolKeys.FUNCTION_CODE,functionCode);
        
        // 启动接口
        Matrix.invokeActivity(SdkUserBaseActivity.this, intent, mPayCallback);
    }
    
    protected Intent doServerTokenId(QihooUserInfo usrinfo, boolean isLandScape,int functionCode) {

        if (!checkLoginInfo(usrinfo)) {
            return null;
        }

        if(Matrix.isOnline()){
        	if(!isAccessTokenValid) {
                Toast.makeText(SdkUserBaseActivity.this, R.string.access_token_invalid, Toast.LENGTH_SHORT).show();
                return null;
            }
            if(!isQTValid) {
                Toast.makeText(SdkUserBaseActivity.this, R.string.qt_invalid, Toast.LENGTH_SHORT).show();
                return null;
            }
        }

        boolean isFixed = getCheckBoxBoolean(R.id.isPayFixed);
        // 支付基础参数
        QihooPayInfo payInfo = getQihooPayInfo(isFixed,functionCode);
        Intent intent = getPayIntent(isLandScape, payInfo,functionCode);
        
        // 必需参数，使用360SDK的支付模块:CP可以根据需求选择使用 带有收银台的支付模块 或者 直接调用微信支付模块或者直接调用支付宝支付模块。
        //functionCode 对应三种支付模块：
        //ProtocolConfigs.FUNC_CODE_PAY;//表示 带有360收银台的支付模块。
        //ProtocolConfigs.FUNC_CODE_WEIXIN_PAY;//表示 微信支付模块。
        //ProtocolConfigs.FUNC_CODE_ALI_PAY;//表示支付宝支付模块。
        intent.putExtra(ProtocolKeys.FUNCTION_CODE,functionCode);
        
        // 启动接口
        Matrix.getTokenId(intent, this, new IDispatcherCallback(){

			@Override
			public void onFinished(String data) {
				Log.i("jw", "data:"+data);
				try{
					JSONObject json = new JSONObject(data);
					JSONObject contentJson = json.getJSONObject("content");
					String tokenId = contentJson.optString("token_id");
					String orderId = contentJson.optString("order_token");
					tokenIdEdit.setText(tokenId);
					orderIdEdit.setText(orderId);
				}catch(Exception e){
				}
			}
        	
        });
        
        return intent;
    }
    
    /**
     * 二维码支付
     * @param usrinfo
     * @param isLandScape
     * @param functionCode
     */
    protected void doSdkQRPay(QihooUserInfo usrinfo, boolean isLandScape,int functionCode) {

        if (!checkLoginInfo(usrinfo)) {
            return;
        }

        if(!isAccessTokenValid) {
            Toast.makeText(SdkUserBaseActivity.this, R.string.access_token_invalid, Toast.LENGTH_SHORT).show();
            return;
        }
        if(!isQTValid) {
            Toast.makeText(SdkUserBaseActivity.this, R.string.qt_invalid, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isFixed = getCheckBoxBoolean(R.id.isPayFixed);
        // 支付基础参数
        QihooPayInfo payInfo = getQihooPayInfo(isFixed,functionCode);
        Intent intent = getPayIntent(isLandScape, payInfo,functionCode);

        // 必需参数，使用360SDK的支付模块:CP可以根据需求选择使用 带有收银台的支付模块 或者 直接调用微信支付模块或者直接调用支付宝支付模块。
        //functionCode 对应三种支付模块：
        //ProtocolConfigs.FUNC_CODE_PAY;//表示 带有360收银台的支付模块。
        //ProtocolConfigs.FUNC_CODE_WEIXIN_PAY;//表示 微信支付模块。
        //ProtocolConfigs.FUNC_CODE_ALI_PAY;//表示支付宝支付模块。
        intent.putExtra(ProtocolKeys.FUNCTION_CODE,functionCode);
        // 启动接口
        Matrix.invokeActivity(SdkUserBaseActivity.this, intent, mPayCallback);
    }

    
    // 支付的回调
    protected IDispatcherCallback mPayCallback = new IDispatcherCallback() {

        @Override
        public void onFinished(String data) {
//            Log.d(TAG, "mPayCallback, data is " + data);
            if(TextUtils.isEmpty(data)) {
                return;
            }

            boolean isCallbackParseOk = false;
            JSONObject jsonRes;
            try {
                jsonRes = new JSONObject(data);
                // error_code 状态码： 0 支付成功， -1 支付取消， 1 支付失败， -2 支付进行中,5 海马云环境支付转接处理(此处不需要做处理) ,4010201和4009911 登录状态已失效，引导用户重新登录
                // error_msg 状态描述
                int errorCode = jsonRes.optInt("error_code");
                String errorMsg;
                isCallbackParseOk = true;
                
                switch (errorCode) {
                    case 0:
                    case 1:
                    case -1:
                    case -2: {
                        isAccessTokenValid = true;
                        isQTValid = true;
                        errorMsg = jsonRes.optString("error_msg");
                        String text = getString(R.string.pay_callback_toast, errorCode, errorMsg);
                        Toast.makeText(SdkUserBaseActivity.this, text, Toast.LENGTH_SHORT).show();
                    }
                        break;
                    case 4010201:
                        //acess_token失效
                        isAccessTokenValid = false;
                        Toast.makeText(SdkUserBaseActivity.this, R.string.access_token_invalid, Toast.LENGTH_SHORT).show();
                        break;
                    case 4009911:
                        //QT失效
                        isQTValid = false;
                        Toast.makeText(SdkUserBaseActivity.this, R.string.qt_invalid, Toast.LENGTH_SHORT).show();
                        break;
                    //海马云环境支付转接处理(此处不需要做处理),不是错误码
                    case 5:
                    	isAccessTokenValid = true;
                        isQTValid = true;
                    	errorMsg = jsonRes.optString("error_msg");
                        String text = getString(R.string.pay_callback_toast, errorCode, errorMsg);
                        Toast.makeText(SdkUserBaseActivity.this, text, Toast.LENGTH_SHORT).show();
                        break;
                        
                    //海马云+手助支付时回调
                    case 995:
                    case 996:
                    case 997:
                    case 998:
                    case 999:{
                       	errorMsg = jsonRes.optString("error_msg");
                    	String text_2 = getString(R.string.pay_callback_toast, errorCode, errorMsg);
                    	Toast.makeText(SdkUserBaseActivity.this, text_2, Toast.LENGTH_SHORT).show();
                    }
                    	break;
                    default:
                        break;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            // 用于测试数据格式是否异常。
            if (!isCallbackParseOk) {
                Toast.makeText(SdkUserBaseActivity.this, getString(R.string.data_format_error),
                        Toast.LENGTH_LONG).show();
            }
        }
    };

    // payment end
    @Override
	protected void onResume() {
		super.onResume();
		Matrix.onResume(this);
	}
    @Override
   	protected void onStart() {
   		super.onStart();
   		Matrix.onStart(this);
   	}
    @Override
   	protected void onRestart() {
   		super.onRestart();
   		Matrix.onRestart(this);
   	}
    @Override
   	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
   		super.onActivityResult(requestCode, resultCode, data);
   		Matrix.onActivityResult(this,requestCode, resultCode, data);
   	}
    @Override
   	protected void onPause() {
   		super.onPause();
   		Matrix.onPause(this);
   	}
    @Override
   	protected void onStop() {
   		super.onStop();
   		Matrix.onStop(this);
   	}
    @Override
    protected void onNewIntent(Intent intent) {
    	super.onNewIntent(intent);
    	Matrix.onNewIntent(this,intent);
    } 
    
}
