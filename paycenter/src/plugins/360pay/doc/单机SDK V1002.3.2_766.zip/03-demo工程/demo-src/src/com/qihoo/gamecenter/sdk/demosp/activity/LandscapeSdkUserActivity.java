
package com.qihoo.gamecenter.sdk.demosp.activity;

//import com.qihoo.gamecenter.sdk.common.utils.ToastUtil;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo.gamecenter.sdk.demosp.R;
import com.qihoo.gamecenter.sdk.demosp.activity.plugin.LandscapePluginTestActivity;
import com.qihoo.gamecenter.sdk.demosp.utils.ProgressUtil;
import com.qihoo.gamecenter.sdk.demosp.utils.QihooUserInfo;
import com.qihoo.gamecenter.sdk.matrix.Matrix;
import com.qihoo.gamecenter.sdk.protocols.ProtocolConfigs;

@SuppressLint("NewApi")
public class LandscapeSdkUserActivity extends SdkUserBaseActivity implements OnClickListener{
	
    private TextView mLoginResultView;
    private ProgressDialog mProgress;
    private Intent mServerPayIntent;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
	        case R.id.btn_openpluginwindow:
	    		//打开插件的浮窗
	    		openFloatWindow();
	    		break;
            case R.id.btn_login_choose:
                clearLoginResult();
                doSdkLogin(true);
                break;
            case R.id.btn_switch_account:
                doSdkSwitchAccount(true);
                break;
            case R.id.btn_logout:
                doSdkLogout(mQihooUserInfo);
                clearLoginResult();
                break;
            case R.id.btn_bbs:
                doSdkBBS(mQihooUserInfo, true);
                break;
            case R.id.btn_quit:
                doSdkQuit(true);
                break;
                //ProtocolConfigs.FUNC_CODE_PAY;//表示 带有360收银台的支付模块。
            case R.id.btn_pay:
                doSdkPay(mQihooUserInfo, true,ProtocolConfigs.FUNC_CODE_PAY);
                break;
              //ProtocolConfigs.FUNC_CODE_WEIXIN_PAY;//表示 微信支付模块。
            case R.id.btn_weixin_pay:
                doSdkPay(mQihooUserInfo, true,ProtocolConfigs.FUNC_CODE_WEIXIN_PAY);
                break;
              //ProtocolConfigs.FUNC_CODE_ALI_PAY;//表示支付宝支付模块。
            case R.id.btn_ali_pay:
                doSdkPay(mQihooUserInfo, true,ProtocolConfigs.FUNC_CODE_ALI_PAY);
                break;
            case R.id.btn_qr_pay:
            	doSdkQRPay(mQihooUserInfo, false, ProtocolConfigs.FUNC_CODE_PAY);
            	break;
            case R.id.btn_qr_weixin_pay:
            	doSdkQRPay(mQihooUserInfo, false, ProtocolConfigs.FUNC_CODE_WEIXIN_PAY);
            	break;
            case R.id.btn_qr_ali_pay:
            	doSdkQRPay(mQihooUserInfo, false, ProtocolConfigs.FUNC_CODE_ALI_PAY);
                break;
            case R.id.btn_antAddiction:
                doSdkAntiAddictionQuery(mAccessToken, mQihooUserInfo);
                break;
            case R.id.btn_getuserinfo:
            	doSdkGetUserInfoByCP();
                break;
            case R.id.btn_open_plugin_activity:
            	openPluginTestActivity();
                break;
            case R.id.btn_openkefu:
            	doOpenKefu(mQihooUserInfo,true);
            	break;
            case R.id.btn_open_hook:
            	testHmtlHook();
            	break; 
            case R.id.btn_open2dl_hook:
            	testApk2DownloadlHook();
            	break;	
            case R.id.server_order_btn:
            	doServerPay(mServerPayIntent, mQihooUserInfo, true,ProtocolConfigs.FUNC_CODE_PAY);
            	break;
            case R.id.btn_open_shimingzhi:
            	 doOpenSdkRealName(mQihooUserInfo, true);
            	break;
            case R.id.btn_openshare:
           	      doSdkShare(mQihooUserInfo, true);
           	break;
            default:
                break;
        }
    }
    
    private void openPluginTestActivity() {
        Intent intent = new Intent(this, LandscapePluginTestActivity.class);
        startActivity(intent);
    }
	
    LinearLayout mainView;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sdk_user_activity);
        //设置横屏重力感应屏幕90度和270度
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        resetViews();
        mIsLandscape = true; 
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void resetViews() {
    	
    	mainView = (LinearLayout)findViewById(R.id.mainBase);
    	if (Build.VERSION.SDK_INT >= 14 ) {
    		mainView.setFitsSystemWindows(true);
    		mainView.setClipToPadding(true);
		}
    	
    
//    	mainView.setOnClickListener(mNavBarListener);

        TextView sdkVerView = (TextView) findViewById(R.id.sdk_ver);
        sdkVerView.setText(getString(R.string.sdk_ver) + Matrix.getVersionName(this) + "(" + Matrix.getVersionCode(this) + ")");

        TextView channelView = (TextView) findViewById(R.id.channel);
        channelView.setText(getString(R.string.channel).concat("default"));

        mLoginResultView = (TextView) findViewById(R.id.login_result);

        View btnLoginChoose = findViewById(R.id.btn_login_choose);
        btnLoginChoose.setOnClickListener(this);

        View btnLoginSwitchAccount = findViewById(R.id.btn_switch_account);
        btnLoginSwitchAccount.setOnClickListener(this);

        View btnLogout = findViewById(R.id.btn_logout);
        btnLogout.setOnClickListener(this);

        View bbsBtn = findViewById(R.id.btn_bbs);
        bbsBtn.setOnClickListener(this);

        View bbsPostImage = findViewById(R.id.btn_quit);
        bbsPostImage.setOnClickListener(this);

        View pay = findViewById(R.id.btn_pay);
        pay.setOnClickListener(this);
        
        View weixinPay = findViewById(R.id.btn_weixin_pay);
        weixinPay.setOnClickListener(this);
        
        View aliPay = findViewById(R.id.btn_ali_pay);
        aliPay.setOnClickListener(this);
        
        findViewById(R.id.btn_qr_pay).setOnClickListener(this);
        findViewById(R.id.btn_qr_weixin_pay).setOnClickListener(this);
        findViewById(R.id.btn_qr_ali_pay).setOnClickListener(this);
        findViewById(R.id.btn_openshare).setOnClickListener(this);

        View antAddiction = findViewById(R.id.btn_antAddiction);
        antAddiction.setOnClickListener(this);

        View getuserinfo = findViewById(R.id.btn_getuserinfo);
        getuserinfo.setOnClickListener(this);

        findViewById(R.id.btn_open_plugin_activity).setOnClickListener(this);
        
        findViewById(R.id.btn_openkefu).setOnClickListener(this);
        
        findViewById(R.id.btn_open_hook).setOnClickListener(this);
        
        findViewById(R.id.btn_open_shimingzhi).setOnClickListener(this);
        
        findViewById(R.id.btn_open2dl_hook).setOnClickListener(this);        
        mHookHtml = (EditText)findViewById(R.id.et_hoook_cnt);
        mHookApk = (EditText)findViewById(R.id.et_hoook_apk_cnt);
        
        appUserNameEdit = (EditText)findViewById(R.id.et_appusername);
        
        tokenIdEdit = (EditText)findViewById(R.id.token_txt);
        orderIdEdit = (EditText)findViewById(R.id.order_txt);
        tokenBtn = (Button)findViewById(R.id.gettoken_btn);
        
        tokenBtn.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				mServerPayIntent = doServerTokenId(mQihooUserInfo, false,ProtocolConfigs.FUNC_CODE_PAY);
			}
        });
        
        findViewById(R.id.server_order_btn).setOnClickListener(this);
        
        if(Matrix.isOnline()){
    		findViewById(R.id.send_qid).setVisibility(View.GONE);
    	}
        
        //660新增打开浮窗，设置浮窗位置
        findViewById(R.id.btn_openpluginwindow).setOnClickListener(this);
        
        
    }
    EditText mHookHtml = null;
    EditText mHookApk = null;
    
    private void testHmtlHook(){
    	String url = mHookHtml.getText().toString().trim();
    	
    	if (TextUtils.isEmpty(url)) { 
			Toast.makeText(this, "URL 不能为空~", Toast.LENGTH_SHORT).show();
			return;
		}
    	
    	if (!Patterns.WEB_URL.matcher(url.toString()).matches()) {
    		Toast.makeText(this, "URL 非法，请输入有效的URL链接:"+url, Toast.LENGTH_SHORT).show(); 
			return;
		}
    	  Intent intent = new  Intent();
    	  intent.setAction(Intent.ACTION_VIEW);  
          intent.addCategory(Intent.CATEGORY_DEFAULT);  
          intent.setData(Uri.parse(url));   
          this.startActivity(intent);  
    }

    private void testApk2DownloadlHook(){
    	String url = mHookApk.getText().toString().trim();
    	
    	if (TextUtils.isEmpty(url)) { 
			Toast.makeText(this,"URL 不能为空~", Toast.LENGTH_SHORT).show(); 
			return;
		}
    	
    	if (!Patterns.WEB_URL.matcher(url.toString()).matches()) { 
    		Toast.makeText(this,"URL 非法，请输入有效的URL链接:"+url, Toast.LENGTH_SHORT).show(); 
			return;
		}
    	  Intent intent = new  Intent();
     	  intent.setAction(Intent.ACTION_VIEW);  
           intent.addCategory(Intent.CATEGORY_DEFAULT);  
           intent.setData(Uri.parse(url));   
           this.startActivity(intent);   
  }

 
    
    private void clearLoginResult() {
        mLoginResultView.setText(null);
        mQihooUserInfo = null;
    }

    @Override
    public void onGotUserInfo(QihooUserInfo userInfo) {

        ProgressUtil.dismiss(mProgress);

        if (userInfo != null && userInfo.isValid()) {
            // 保存QihooUserInfo
            mQihooUserInfo = userInfo;
            // 界面显示QihooUser的Id和Name
            mLoginResultView.setText(getLoginResultText());

        } else {
            Toast.makeText(this, R.string.get_user_fail, Toast.LENGTH_SHORT).show();
            clearLoginResult();
        }
    }

    /*
     * 当用户要退出游戏时，需要调用SDK的退出接口。
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                doSdkQuit(mIsLandscape);
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }
    
    /*@SuppressLint("NewApi")
 	private View.OnClickListener mNavBarListener = new View.OnClickListener() {  
 		@Override
 		public void onClick(View v) {  
			 		   int i = mainView.getSystemUiVisibility();  
				        if (i == View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) {  
				        	mainView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);  
				        } else if (i == View.SYSTEM_UI_FLAG_VISIBLE){  
				        	mainView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);  
				        } else if (i == View.SYSTEM_UI_FLAG_LOW_PROFILE) {  
				        	mainView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);  
				        }   
				        else if (i == View.SYSTEM_UI_FLAG_VISIBLE) {  
				        	mainView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);  
				        }  
 		}
 	};*/
}
