package com.qihoo.gamecenter.sdk.demosp;

import com.qihoo.gamecenter.sdk.matrix.Matrix;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;


public class SdkDemoApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        // 此处必须先初始化360SDK
        Matrix.initInApplication(this);
    }
    
    @Override
    protected void attachBaseContext(Context base) {
    	super.attachBaseContext(base);
    	//遇到方法数超过了65536
        MultiDex.install(this);
    }
}
