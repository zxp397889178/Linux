
package com.qihoo.gamecenter.sdk.demosp.activity.plugin;

import android.os.Bundle;

public class LandscapePluginTestActivity extends PluginTestActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

}
